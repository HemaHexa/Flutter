InvestMate — Combined Wealth + Circular Swipe package

This ZIP includes BOTH:
1. The Wealth Management experience:
   - Net worth overview
   - Assets and liabilities
   - Wealth growth chart with 1M, 3M, 6M and 1Y selectors
   - Circular visuals on the left with amounts and percentages on the right
2. Circular carousel navigation:
   - Swipe right: Home -> My Wealth -> My Investments -> Credit Health -> Home
   - Swipe left: Home -> Credit Health -> My Investments -> My Wealth -> Home

Install:
- Extract this ZIP.
- Copy the included `lib` folder into your existing Flutter project, replacing the old `lib` folder.
- Run `flutter pub get`
- Run `flutter run -d emulator-5554`

All financial data is illustrative mock data.

3. Wealth conversational prompts:
   - Explain my assets
   - How has my wealth grown?
   - Review my liabilities
   Each chip opens the in-app demo AI conversation with a contextual mock answer and follow-up input. No real financial accounts or AI service are connected.
