import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const InvestMateApp());
}

class InvestMateApp extends StatelessWidget {
  const InvestMateApp({super.key});

  @override
  Widget build(BuildContext context) {
    const background = Color(0xFF10091B);

    return MaterialApp(
      title: 'InvestMate',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: background,
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFC18BFF),
          secondary: Color(0xFFDB8CFF),
          surface: Color(0xFF21152F),
        ),
        fontFamily: 'Roboto',
      ),
      home: const HomeScreen(),
    );
  }
}
