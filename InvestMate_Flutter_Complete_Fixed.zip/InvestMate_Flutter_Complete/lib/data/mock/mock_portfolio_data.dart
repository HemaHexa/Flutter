import '../../models/investment_model.dart';
import '../../models/portfolio_model.dart';
class MockPortfolioData {
 static const portfolio=PortfolioModel(investedAmount:755556,currentValue:850000,totalReturns:94444,returnPercentage:12.5);
 static const allocations=<InvestmentModel>[
  InvestmentModel(name:'Stocks',category:'Equity',investedAmount:300000,currentValue:340000,returnPercentage:13.3),
  InvestmentModel(name:'Mutual Funds',category:'Funds',investedAmount:300000,currentValue:340000,returnPercentage:13.3),
  InvestmentModel(name:'Fixed Deposits',category:'Fixed income',investedAmount:155556,currentValue:170000,returnPercentage:9.3)];
 static const holdings=<InvestmentModel>[
  InvestmentModel(name:'Reliance Industries',category:'Stock • Energy',investedAmount:104348,currentValue:120000,returnPercentage:15),
  InvestmentModel(name:'Tata Consultancy Services',category:'Stock • IT',investedAmount:90909,currentValue:100000,returnPercentage:10),
  InvestmentModel(name:'HDFC Bank',category:'Stock • Banking',investedAmount:74074,currentValue:80000,returnPercentage:8),
  InvestmentModel(name:'Infosys',category:'Stock • IT',investedAmount:37736,currentValue:40000,returnPercentage:6)];
 static const performance=<double>[62,65,64,70,68,73,72,78,76,84,88,94];
}
