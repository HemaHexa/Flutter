enum MessageSender { user, assistant }
class ChatMessageModel { final String text; final MessageSender sender; const ChatMessageModel({required this.text,required this.sender}); }
