class ChatService {
 String getResponse(String question) {
  final q=question.toLowerCase();
  if(q.contains('portfolio')||q.contains('overview')||q.contains('value')) return 'Here is your portfolio overview. Your investments are currently worth ₹8,50,000, with a gain of ₹94,444 (+12.5%).';
  if(q.contains('return')||q.contains('performance')||q.contains('profit')) return 'Your sample portfolio has generated a positive return of 12.5%. The chart below shows an illustrative trend over 12 months.';
  if(q.contains('allocation')||q.contains('asset')||q.contains('diversif')) return 'Your sample portfolio is spread across stocks, mutual funds and fixed deposits: about 40%, 40% and 20%.';
  if(q.contains('holding')||q.contains('stock')||q.contains('investment')||q.contains('compare')) return 'Here are some investments in your sample portfolio. Review their current values and returns below.';
  return 'I can help you explore your portfolio, understand returns, review asset allocation and compare investments. Try a suggested question below.';
 }
}
