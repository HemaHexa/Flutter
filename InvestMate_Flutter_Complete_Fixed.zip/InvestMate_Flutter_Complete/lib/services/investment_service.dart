import '../data/mock/mock_portfolio_data.dart';
import '../models/investment_model.dart';
import '../models/portfolio_model.dart';
class InvestmentService { PortfolioModel getPortfolio()=>MockPortfolioData.portfolio; List<InvestmentModel> getAllocations()=>MockPortfolioData.allocations; List<InvestmentModel> getHoldings()=>MockPortfolioData.holdings; List<double> getPerformance()=>MockPortfolioData.performance; }
