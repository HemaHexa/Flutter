import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';
import '../models/chat_message_model.dart';
class ChatBubble extends StatelessWidget {
 final ChatMessageModel message; const ChatBubble({super.key,required this.message});
 @override Widget build(BuildContext context) { final user=message.sender==MessageSender.user; return Align(alignment:user?Alignment.centerRight:Alignment.centerLeft,child:Container(constraints:BoxConstraints(maxWidth:MediaQuery.of(context).size.width*.82),margin:const EdgeInsets.symmetric(vertical:6),padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:user?AppColors.softBlue:AppColors.white,borderRadius:BorderRadius.circular(18),border:Border.all(color:AppColors.border)),child:Text(message.text,style:const TextStyle(color:AppColors.navy,height:1.4)))); }
}
