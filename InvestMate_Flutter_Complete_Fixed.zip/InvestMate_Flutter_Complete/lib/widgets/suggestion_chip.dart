import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';
class SuggestionChip extends StatelessWidget { final String label; final VoidCallback onTap; const SuggestionChip({super.key,required this.label,required this.onTap}); @override Widget build(BuildContext context)=>ActionChip(onPressed:onTap,label:Text(label,style:const TextStyle(color:AppColors.blue,fontSize:12,fontWeight:FontWeight.w600)),backgroundColor:AppColors.white,side:const BorderSide(color:AppColors.border)); }
