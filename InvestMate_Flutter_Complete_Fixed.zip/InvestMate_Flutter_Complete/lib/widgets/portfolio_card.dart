import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';
import '../models/portfolio_model.dart';

class PortfolioCard extends StatelessWidget {
  final PortfolioModel portfolio;
  const PortfolioCard({super.key, required this.portfolio});

  String money(double value) {
    final raw = value.toStringAsFixed(0);
    final out = StringBuffer();
    for (var i = 0; i < raw.length; i++) {
      out.write(raw[i]);
      final left = raw.length - i - 1;
      if (left > 0 && left % 3 == 0) out.write(',');
    }
    return '₹${out.toString()}';
  }

  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(color: AppColors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.border)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('TOTAL PORTFOLIO VALUE', style: TextStyle(color: AppColors.slate, fontSize: 10, letterSpacing: 1, fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      Text(money(portfolio.currentValue), style: const TextStyle(color: AppColors.navy, fontSize: 28, fontWeight: FontWeight.w800)),
      const SizedBox(height: 16),
      Row(children: [
        Expanded(child: _metric('Invested', money(portfolio.investedAmount))),
        Expanded(child: _metric('Total returns', '+${money(portfolio.totalReturns)}', positive: true)),
      ]),
      const SizedBox(height: 14),
      Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7), decoration: BoxDecoration(color: const Color(0xFFEAF7F1), borderRadius: BorderRadius.circular(20)),
        child: Text('+${portfolio.returnPercentage.toStringAsFixed(1)}% overall return', style: const TextStyle(color: AppColors.green, fontWeight: FontWeight.w700, fontSize: 12))),
    ]),
  );

  Widget _metric(String label, String value, {bool positive = false}) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(label, style: const TextStyle(color: AppColors.slate, fontSize: 11)),
    const SizedBox(height: 4),
    Text(value, style: TextStyle(color: positive ? AppColors.green : AppColors.navy, fontWeight: FontWeight.w700, fontSize: 13)),
  ]);
}
