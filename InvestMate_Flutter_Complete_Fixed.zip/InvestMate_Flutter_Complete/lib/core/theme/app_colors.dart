import 'package:flutter/material.dart';
class AppColors {
 static const white=Color(0xFFFFFFFF), background=Color(0xFFF3F5F8), slate=Color(0xFF65758B), blue=Color(0xFF356AC3), navy=Color(0xFF182B45), softBlue=Color(0xFFEAF1FC), green=Color(0xFF23966B), red=Color(0xFFD9534F), border=Color(0xFFE9EDF3);
}
