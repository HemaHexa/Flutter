import 'package:flutter/material.dart';
import 'app_colors.dart';
class AppTheme {
 static ThemeData get light => ThemeData(useMaterial3:true, colorScheme:ColorScheme.fromSeed(seedColor:AppColors.blue,brightness:Brightness.light), scaffoldBackgroundColor:AppColors.background, appBarTheme:const AppBarTheme(backgroundColor:AppColors.background,foregroundColor:AppColors.navy,elevation:0), inputDecorationTheme:InputDecorationTheme(filled:true,fillColor:AppColors.white,contentPadding:const EdgeInsets.symmetric(horizontal:16,vertical:14),border:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:const BorderSide(color:AppColors.border))));
}
