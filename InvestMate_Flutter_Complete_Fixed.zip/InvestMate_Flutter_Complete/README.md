# InvestMate Flutter starter

Copy the `lib` folder into your existing Flutter project's root, replacing its current `lib` folder. Keep your existing `pubspec.yaml`, `android/`, and `ios/` folders.

Run:
```bash
flutter pub get
flutter run
```
No extra packages are required. All investment data is local illustrative mock data, not financial advice.
