import 'package:flutter/material.dart';
import '../models/investment.dart';

const mockInvestments = <Investment>[
  Investment(name: 'Reliance Industries', symbol: 'RELIANCE', type: 'Stock',
    value: 82450, change: 2.8, colorValue: 0xFF246A91),
  Investment(name: 'HDFC Bank', symbol: 'HDFCBANK', type: 'Stock',
    value: 56200, change: 1.4, colorValue: 0xFF159A91),
  Investment(name: 'Parag Parikh Flexi Cap', symbol: 'PPFAS', type: 'Mutual Fund',
    value: 48600, change: 4.2, colorValue: 0xFF8B78B8),
  Investment(name: 'SBI Fixed Deposit', symbol: 'SBI FD', type: 'Fixed Deposit',
    value: 100000, change: 0.6, colorValue: 0xFFE3A34A),
];
const allocation = <Map<String, Object>>[
  {'label': 'Stocks', 'value': 52, 'color': Color(0xFF159A91)},
  {'label': 'Mutual funds', 'value': 28, 'color': Color(0xFF6B8FC5)},
  {'label': 'Fixed deposits', 'value': 20, 'color': Color(0xFFE3A34A)},
];
