import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../models/investment.dart';

class InvestmentDetailsScreen extends StatelessWidget {
  const InvestmentDetailsScreen({super.key, required this.investment});
  final Investment investment;
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.background,
    appBar: AppBar(title: const Text('Investment details', style: AppTextStyles.title)),
    body: ListView(padding: const EdgeInsets.fromLTRB(20, 8, 20, 30), children: [
      Container(padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: Colors.white,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: AppColors.border)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(height: 48, width: 48,
              decoration: BoxDecoration(
                color: Color(investment.colorValue).withValues(alpha: .12),
                borderRadius: BorderRadius.circular(15)),
              child: Icon(Icons.show_chart_rounded,
                color: Color(investment.colorValue), size: 25)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(investment.name, style: AppTextStyles.title),
                const SizedBox(height: 4),
                Text('${investment.symbol} • ${investment.type}',
                  style: AppTextStyles.caption),
              ])),
          ]),
          const SizedBox(height: 26),
          const Text('CURRENT VALUE', style: TextStyle(
            color: AppColors.secondaryText, fontSize: 10,
            letterSpacing: 1, fontWeight: FontWeight.w700)),
          const SizedBox(height: 7),
          Text('₹${investment.value.toStringAsFixed(0)}',
            style: AppTextStyles.amount),
          const SizedBox(height: 6),
          Text('+${investment.change.toStringAsFixed(1)}%',
            style: const TextStyle(color: AppColors.positive,
              fontWeight: FontWeight.w800)),
          const SizedBox(height: 22),
          SizedBox(height: 70, child: CustomPaint(
            painter: _TrendPainter(), child: const SizedBox.expand())),
          const SizedBox(height: 8),
          const Text('Illustrative performance trend', style: AppTextStyles.caption),
        ])),
      const SizedBox(height: 18),
      const Text('Investment overview', style: AppTextStyles.subHeading),
      const SizedBox(height: 12),
      _DetailRow(label: 'Investment type', value: investment.type),
      _DetailRow(label: 'Investment value',
        value: '₹${investment.value.toStringAsFixed(0)}'),
      _DetailRow(label: 'Illustrative return',
        value: '+${investment.change.toStringAsFixed(1)}%'),
      const SizedBox(height: 18),
      Container(padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: AppColors.lightTeal,
          borderRadius: BorderRadius.circular(17)),
        child: const Text('This screen uses sample values for demonstration. '
          'Actual investment values and returns can change with market conditions.',
          style: TextStyle(color: AppColors.secondaryText,
            fontSize: 12, height: 1.5))),
    ]),
  );
}
class _DetailRow extends StatelessWidget {
  const _DetailRow({required this.label, required this.value});
  final String label, value;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 12),
    child: Row(children: [
      Expanded(child: Text(label, style: AppTextStyles.body)),
      Text(value, style: const TextStyle(color: AppColors.navy,
        fontWeight: FontWeight.w700, fontSize: 13)),
    ]));
}
class _TrendPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    const vals = [.75, .64, .69, .48, .53, .32, .4, .2, .25, .08];
    final path = Path();
    for (var i = 0; i < vals.length; i++) {
      final p = Offset(size.width * i / (vals.length - 1), size.height * vals[i]);
      if (i == 0) { path.moveTo(p.dx, p.dy); } else { path.lineTo(p.dx, p.dy); }
    }
    canvas.drawPath(path, Paint()..color = AppColors.teal
      ..style = PaintingStyle.stroke..strokeWidth = 3
      ..strokeCap = StrokeCap.round..strokeJoin = StrokeJoin.round);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
