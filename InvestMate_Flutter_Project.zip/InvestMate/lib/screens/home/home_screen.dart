import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../data/mock_data.dart';
import '../../widgets/metric_card.dart';
import '../../widgets/section_title.dart';
import '../../widgets/investment_tile.dart';
import '../assistant/assistant_screen.dart';
import '../portfolio/portfolio_screen.dart';
import '../investment_details/investment_details_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  void openAssistant(BuildContext context) => Navigator.push(context,
    MaterialPageRoute(builder: (_) => const AssistantScreen()));
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.background,
    body: Container(decoration: const BoxDecoration(
      gradient: AppColors.oceanGradient),
      child: SafeArea(child: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [SliverPadding(
          padding: const EdgeInsets.fromLTRB(22, 18, 22, 30),
          sliver: SliverList(delegate: SliverChildListDelegate([
            Row(children: [
              Container(height: 43, width: 43,
                decoration: BoxDecoration(color: AppColors.lightTeal,
                  borderRadius: BorderRadius.circular(14)),
                child: const Icon(Icons.water_drop_rounded, color: AppColors.teal)),
              const SizedBox(width: 10),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('InvestMate', style: AppTextStyles.title.copyWith(fontSize: 18)),
                const Text('Your intelligent investment guide',
                  style: AppTextStyles.caption)]),
              const Spacer(),
              IconButton(onPressed: () {},
                icon: const Icon(Icons.notifications_none_rounded,
                  color: AppColors.navy, size: 26)),
            ]),
            const SizedBox(height: 27),
            const Text('Good morning, Hema 👋',
              style: TextStyle(color: AppColors.secondaryText, fontSize: 14)),
            const SizedBox(height: 6),
            const Text('Let’s grow your wealth.', style: AppTextStyles.heading),
            const SizedBox(height: 20),
            Container(padding: const EdgeInsets.all(21),
              decoration: BoxDecoration(gradient: AppColors.tealGradient,
                borderRadius: BorderRadius.circular(24),
                boxShadow: [BoxShadow(color: AppColors.teal.withValues(alpha: .18),
                  blurRadius: 22, offset: const Offset(0, 10))]),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('TOTAL INVESTMENT VALUE',
                  style: TextStyle(color: Colors.white70, fontSize: 10,
                    letterSpacing: 1.2, fontWeight: FontWeight.w700)),
                const SizedBox(height: 10),
                const Text('₹2,87,250', style: TextStyle(color: Colors.white,
                  fontSize: 32, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                const Row(children: [
                  Icon(Icons.trending_up_rounded, color: Color(0xFFB9F0D9), size: 17),
                  SizedBox(width: 5),
                  Text('+₹12,840  (+4.68%)', style: TextStyle(
                    color: Color(0xFFB9F0D9), fontWeight: FontWeight.w700,
                    fontSize: 12)),
                  Spacer(),
                  Text('Overall returns', style: TextStyle(
                    color: Colors.white70, fontSize: 11)),
                ]),
                const SizedBox(height: 18),
                Container(height: 1, color: Colors.white24),
                const SizedBox(height: 13),
                const Row(children: [
                  Expanded(child: _Stat(label: 'Invested', value: '₹2,74,410')),
                  Expanded(child: _Stat(label: 'Today’s P&L', value: '+₹1,240')),
                ]),
              ])),
            const SizedBox(height: 19),
            const Row(children: [
              Expanded(child: MetricCard(label: 'Stocks', value: '₹1.39L',
                icon: Icons.show_chart_rounded, note: '+3.2%')),
              SizedBox(width: 11),
              Expanded(child: MetricCard(label: 'Mutual funds', value: '₹76.8K',
                icon: Icons.pie_chart_outline_rounded, note: '+5.1%')),
            ]),
            const SizedBox(height: 25),
            SectionTitle('Your investments', action: 'View all',
              onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const PortfolioScreen()))),
            const SizedBox(height: 5),
            Container(padding: const EdgeInsets.symmetric(horizontal: 15),
              decoration: BoxDecoration(color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.border)),
              child: Column(children: mockInvestments.take(3).map((item) =>
                InvestmentTile(investment: item, onTap: () =>
                  Navigator.push(context, MaterialPageRoute(builder: (_) =>
                    InvestmentDetailsScreen(investment: item)))).toList())),
            const SizedBox(height: 23),
            Container(padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(color: const Color(0xFFE9F5F3),
                borderRadius: BorderRadius.circular(21),
                border: Border.all(color: const Color(0xFFD8ECE8))),
              child: const Row(children: [
                CircleAvatar(backgroundColor: Colors.white,
                  child: Icon(Icons.auto_awesome_rounded, color: AppColors.teal)),
                SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('A little insight for you', style: TextStyle(
                      color: AppColors.navy, fontWeight: FontWeight.w800, fontSize: 14)),
                    SizedBox(height: 4),
                    Text('Your mutual fund allocation has grown this month.',
                      style: TextStyle(color: AppColors.secondaryText,
                        fontSize: 11, height: 1.4)),
                  ])),
              ])),
            const SizedBox(height: 18),
            InkWell(onTap: () => openAssistant(context),
              borderRadius: BorderRadius.circular(22),
              child: Container(padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(color: AppColors.navy,
                  borderRadius: BorderRadius.circular(22)),
                child: const Row(children: [
                  Icon(Icons.auto_awesome, color: AppColors.seafoam, size: 27),
                  SizedBox(width: 13),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Ask your AI investment assistant', style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14)),
                      SizedBox(height: 4),
                      Text('Get clarity on your investments',
                        style: TextStyle(color: Colors.white70, fontSize: 11)),
                    ])),
                  Icon(Icons.arrow_forward_rounded, color: Colors.white),
                ]))),
          ])),
        )]))),
    floatingActionButton: FloatingActionButton(
      onPressed: () => openAssistant(context),
      backgroundColor: AppColors.teal, foregroundColor: Colors.white,
      child: const Icon(Icons.chat_rounded)),
  );
}
class _Stat extends StatelessWidget {
  const _Stat({required this.label, required this.value});
  final String label, value;
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(color: Colors.white70, fontSize: 10)),
      const SizedBox(height: 4),
      Text(value, style: const TextStyle(color: Colors.white,
        fontSize: 13, fontWeight: FontWeight.w700)),
    ]);
}
