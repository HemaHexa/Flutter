import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../home/home_screen.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});
  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}
class _WelcomeScreenState extends State<WelcomeScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController controller;
  late final Animation<double> scale;
  @override
  void initState() {
    super.initState();
    controller = AnimationController(vsync: this,
      duration: const Duration(seconds: 3))..repeat(reverse: true);
    scale = Tween<double>(begin: .94, end: 1.06).animate(
      CurvedAnimation(parent: controller, curve: Curves.easeInOut));
  }
  @override
  void dispose() { controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Container(width: double.infinity,
      decoration: const BoxDecoration(gradient: AppColors.oceanGradient),
      child: SafeArea(child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 27),
        child: Column(children: [
          const SizedBox(height: 24),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.water_drop_rounded, color: AppColors.teal, size: 29),
            const SizedBox(width: 8),
            Text('InvestMate', style: AppTextStyles.appName),
          ]),
          const Spacer(flex: 2),
          AnimatedBuilder(animation: scale, builder: (context, child) =>
            Transform.scale(scale: scale.value, child: Container(
              height: 218, width: 218,
              decoration: BoxDecoration(shape: BoxShape.circle,
                gradient: const RadialGradient(colors: [
                  Colors.white, Color(0xFFA6DCD5), Color(0xFF159A91)],
                  stops: [0.08, .58, 1]),
                boxShadow: [BoxShadow(color: AppColors.teal.withValues(alpha: .25),
                  blurRadius: 55, spreadRadius: 14)]),
              child: const Icon(Icons.auto_awesome_rounded,
                color: Colors.white, size: 76)))),
          const Spacer(flex: 2),
          Text('Your wealth.\nYour goals.\nOne intelligent guide.',
            textAlign: TextAlign.center,
            style: AppTextStyles.heading.copyWith(fontSize: 30, height: 1.3)),
          const SizedBox(height: 17),
          Text('Meet your personal investment assistant. Explore opportunities, '
            'understand your portfolio and make smarter investment decisions.',
            textAlign: TextAlign.center,
            style: AppTextStyles.body.copyWith(fontSize: 14.5, height: 1.7)),
          const Spacer(flex: 2),
          SizedBox(width: double.infinity, height: 57,
            child: ElevatedButton(
              onPressed: () => Navigator.of(context).pushReplacement(
                PageRouteBuilder(pageBuilder: (_, animation, __) => const HomeScreen(),
                  transitionsBuilder: (_, animation, __, child) =>
                    FadeTransition(opacity: animation, child: child),
                  transitionDuration: const Duration(milliseconds: 550))),
              child: const Row(mainAxisAlignment: MainAxisAlignment.center,
                children: [Text('Get Started'), SizedBox(width: 10),
                  Icon(Icons.arrow_forward_rounded)]))),
          const SizedBox(height: 17),
          const Text('YOUR JOURNEY TO SMARTER INVESTING STARTS HERE',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 9, letterSpacing: 1.2,
              color: AppColors.secondaryText, fontWeight: FontWeight.w700)),
          const SizedBox(height: 20),
        ])))));
}
