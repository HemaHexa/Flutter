import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';

class AssistantScreen extends StatefulWidget {
  const AssistantScreen({super.key});
  @override
  State<AssistantScreen> createState() => _AssistantScreenState();
}
class _AssistantScreenState extends State<AssistantScreen> {
  final input = TextEditingController();
  final messages = <_Message>[
    const _Message('Hi Hema! I’m your InvestMate assistant. I can help you '
      'understand your portfolio, explore investment concepts and think through '
      'your goals. What would you like to explore today?', false),
  ];
  final suggestions = ['Review my portfolio', 'Explain mutual funds',
    'How can I diversify?'];

  void send([String? suggestion]) {
    final text = (suggestion ?? input.text).trim();
    if (text.isEmpty) return;
    setState(() {
      messages.add(_Message(text, true));
      input.clear();
      messages.add(_Message(reply(text), false));
    });
  }
  String reply(String question) {
    final q = question.toLowerCase();
    if (q.contains('portfolio') || q.contains('review')) {
      return 'Your sample portfolio is valued at ₹2,87,250, with an illustrative '
        'overall return of 4.68%. Your largest allocation is in stocks. Review '
        'whether that balance matches your risk comfort and goals.';
    }
    if (q.contains('mutual')) {
      return 'A mutual fund pools money from multiple investors and invests it '
        'in a portfolio of assets. A fund manager follows the fund’s stated strategy. '
        'Returns are market-linked unless the product specifies otherwise.';
    }
    if (q.contains('divers') || q.contains('allocation')) {
      return 'Diversification means spreading investments across different assets, '
        'sectors or instruments. It may reduce concentration risk, but cannot '
        'eliminate market risk. Consider your time horizon and risk comfort.';
    }
    return 'That’s a thoughtful question. I can help you explore the concept, '
      'compare investment types and understand possible risks. What is your time '
      'horizon and what are you hoping to achieve?';
  }
  @override
  void dispose() { input.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.background,
    appBar: AppBar(title: Row(children: [
      Container(height: 37, width: 37,
        decoration: const BoxDecoration(gradient: AppColors.tealGradient,
          shape: BoxShape.circle),
        child: const Icon(Icons.auto_awesome, color: Colors.white, size: 19)),
      const SizedBox(width: 10),
      const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('InvestMate AI', style: TextStyle(fontSize: 16,
          fontWeight: FontWeight.w800, color: AppColors.navy)),
        Text('Your investment companion', style: TextStyle(fontSize: 10,
          color: AppColors.secondaryText)),
      ]),
    ])),
    body: Column(children: [
      Container(height: 1, color: AppColors.border),
      Expanded(child: ListView(padding: const EdgeInsets.all(17), children: [
        Center(child: Container(padding: const EdgeInsets.symmetric(
          horizontal: 12, vertical: 6),
          decoration: BoxDecoration(color: AppColors.lightTeal,
            borderRadius: BorderRadius.circular(20)),
          child: const Text('YOUR PERSONAL INVESTMENT SPACE',
            style: TextStyle(color: AppColors.teal, fontSize: 9,
              fontWeight: FontWeight.w800, letterSpacing: 1)))),
        const SizedBox(height: 18),
        ...messages.map((m) => _Bubble(message: m)),
        if (messages.length == 1) ...[
          const SizedBox(height: 12),
          const Text('Try asking', style: AppTextStyles.title),
          const SizedBox(height: 10),
          ...suggestions.map((s) => Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Align(alignment: Alignment.centerLeft,
              child: ActionChip(label: Text(s), onPressed: () => send(s),
                backgroundColor: Colors.white,
                side: const BorderSide(color: AppColors.border),
                labelStyle: const TextStyle(color: AppColors.navy,
                  fontWeight: FontWeight.w600))))),
        ],
      ])),
      Container(padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        decoration: const BoxDecoration(color: Colors.white,
          border: Border(top: BorderSide(color: AppColors.border))),
        child: Row(children: [
          Expanded(child: TextField(controller: input,
            textInputAction: TextInputAction.send,
            onSubmitted: (_) => send(),
            decoration: const InputDecoration(
              hintText: 'Ask anything about investing...',
              prefixIcon: Icon(Icons.chat_bubble_outline_rounded,
                color: AppColors.secondaryText, size: 19)))),
          const SizedBox(width: 9),
          IconButton.filled(onPressed: () => send(),
            style: IconButton.styleFrom(backgroundColor: AppColors.teal,
              foregroundColor: Colors.white, fixedSize: const Size(49, 49)),
            icon: const Icon(Icons.arrow_upward_rounded)),
        ])),
    ]),
  );
}
class _Message {
  const _Message(this.text, this.isUser);
  final String text;
  final bool isUser;
}
class _Bubble extends StatelessWidget {
  const _Bubble({required this.message});
  final _Message message;
  @override
  Widget build(BuildContext context) => Align(
    alignment: message.isUser ? Alignment.centerRight : Alignment.centerLeft,
    child: Container(
      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .83),
      margin: const EdgeInsets.only(bottom: 13),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: message.isUser ? AppColors.teal : Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(18), topRight: const Radius.circular(18),
          bottomLeft: Radius.circular(message.isUser ? 18 : 5),
          bottomRight: Radius.circular(message.isUser ? 5 : 18)),
        border: message.isUser ? null : Border.all(color: AppColors.border)),
      child: Text(message.text, style: TextStyle(
        color: message.isUser ? Colors.white : AppColors.primaryText,
        fontSize: 13, height: 1.5))));
}
