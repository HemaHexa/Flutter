import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../data/mock_data.dart';
import '../../widgets/investment_tile.dart';
import '../investment_details/investment_details_screen.dart';

class PortfolioScreen extends StatelessWidget {
  const PortfolioScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.background,
    appBar: AppBar(title: const Text('My portfolio', style: AppTextStyles.subHeading)),
    body: ListView(padding: const EdgeInsets.fromLTRB(20, 8, 20, 30), children: [
      Container(padding: const EdgeInsets.all(21),
        decoration: BoxDecoration(gradient: AppColors.tealGradient,
          borderRadius: BorderRadius.circular(23)),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('TOTAL PORTFOLIO VALUE', style: TextStyle(color: Colors.white70,
            fontSize: 10, letterSpacing: 1.1, fontWeight: FontWeight.w700)),
          SizedBox(height: 9),
          Text('₹2,87,250', style: TextStyle(color: Colors.white,
            fontSize: 31, fontWeight: FontWeight.w800)),
          SizedBox(height: 7),
          Text('+₹12,840  (+4.68%) overall returns', style: TextStyle(
            color: Color(0xFFB9F0D9), fontSize: 12, fontWeight: FontWeight.w700)),
        ])),
      const SizedBox(height: 24),
      const Text('All holdings', style: AppTextStyles.subHeading),
      const SizedBox(height: 7),
      Container(padding: const EdgeInsets.symmetric(horizontal: 15),
        decoration: BoxDecoration(color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.border)),
        child: Column(children: mockInvestments.map((item) => InvestmentTile(
          investment: item, onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) =>
              InvestmentDetailsScreen(investment: item))))).toList())),
      const SizedBox(height: 20),
      const Text('Asset mix', style: AppTextStyles.subHeading),
      const SizedBox(height: 13),
      Container(padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.border)),
        child: Column(children: allocation.map((a) {
          final color = a['color'] as Color;
          final value = a['value'] as int;
          return Padding(padding: const EdgeInsets.only(bottom: 15),
            child: Column(children: [
              Row(children: [
                Container(height: 9, width: 9, decoration: BoxDecoration(
                  color: color, shape: BoxShape.circle)),
                const SizedBox(width: 8),
                Expanded(child: Text(a['label'] as String,
                  style: const TextStyle(color: AppColors.navy,
                    fontWeight: FontWeight.w600, fontSize: 12))),
                Text('$value%', style: const TextStyle(color: AppColors.navy,
                  fontWeight: FontWeight.w800)),
              ]),
              const SizedBox(height: 8),
              ClipRRect(borderRadius: BorderRadius.circular(10),
                child: LinearProgressIndicator(value: value / 100, minHeight: 7,
                  backgroundColor: AppColors.mist, color: color)),
            ]));
        }).toList())),
      const SizedBox(height: 12),
      const Text('All values are illustrative mock data for this prototype.',
        style: TextStyle(color: AppColors.mutedText, fontSize: 10)),
    ]),
  );
}
