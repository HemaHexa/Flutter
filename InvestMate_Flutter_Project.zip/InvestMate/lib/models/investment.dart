class Investment {
  const Investment({required this.name, required this.symbol, required this.type,
    required this.value, required this.change, required this.colorValue});
  final String name, symbol, type;
  final double value, change;
  final int colorValue;
}
