import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';

class MetricCard extends StatelessWidget {
  const MetricCard({super.key, required this.label, required this.value,
    required this.icon, this.note});
  final String label, value;
  final IconData icon;
  final String? note;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: AppColors.border)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Icon(icon, color: AppColors.teal, size: 19),
        const Spacer(), if (note != null) Text(note!,
          style: const TextStyle(color: AppColors.positive,
            fontSize: 11, fontWeight: FontWeight.w700))]),
      const SizedBox(height: 13),
      Text(value, style: const TextStyle(color: AppColors.navy,
        fontSize: 19, fontWeight: FontWeight.w800)),
      const SizedBox(height: 4),
      Text(label, style: const TextStyle(color: AppColors.secondaryText,
        fontSize: 11)),
    ]));
}
