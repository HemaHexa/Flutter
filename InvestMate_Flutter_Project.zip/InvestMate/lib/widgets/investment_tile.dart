import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';
import '../models/investment.dart';

class InvestmentTile extends StatelessWidget {
  const InvestmentTile({super.key, required this.investment, this.onTap});
  final Investment investment;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap, borderRadius: BorderRadius.circular(16),
    child: Padding(padding: const EdgeInsets.symmetric(vertical: 13),
      child: Row(children: [
        Container(height: 43, width: 43,
          decoration: BoxDecoration(
            color: Color(investment.colorValue).withValues(alpha: .12),
            borderRadius: BorderRadius.circular(14)),
          child: Icon(Icons.show_chart_rounded,
            color: Color(investment.colorValue))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(investment.name, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w700,
                color: AppColors.navy, fontSize: 13)),
            const SizedBox(height: 4),
            Text('${investment.symbol} • ${investment.type}',
              style: const TextStyle(fontSize: 11,
                color: AppColors.secondaryText)),
          ])),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text('₹${investment.value.toStringAsFixed(0)}',
            style: const TextStyle(fontWeight: FontWeight.w800,
              color: AppColors.navy, fontSize: 13)),
          const SizedBox(height: 4),
          Text('+${investment.change.toStringAsFixed(1)}%',
            style: const TextStyle(fontSize: 11, color: AppColors.positive,
              fontWeight: FontWeight.w700)),
        ]),
      ])));
}
