import 'package:flutter/material.dart';
import 'core/theme/app_theme.dart';
import 'screens/welcome/welcome_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const InvestMateApp());
}

class InvestMateApp extends StatelessWidget {
  const InvestMateApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'InvestMate',
    debugShowCheckedModeBanner: false,
    theme: AppTheme.lightTheme,
    home: const WelcomeScreen(),
  );
}
