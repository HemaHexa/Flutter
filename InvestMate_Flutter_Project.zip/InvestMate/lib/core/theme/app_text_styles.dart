import 'package:flutter/material.dart';
import 'app_colors.dart';

class AppTextStyles {
  AppTextStyles._();
  static const appName = TextStyle(fontSize: 27, fontWeight: FontWeight.w800,
    color: AppColors.navy, letterSpacing: -.8);
  static const heading = TextStyle(fontSize: 27, fontWeight: FontWeight.w800,
    color: AppColors.primaryText, letterSpacing: -.7, height: 1.2);
  static const subHeading = TextStyle(fontSize: 20, fontWeight: FontWeight.w700,
    color: AppColors.primaryText);
  static const title = TextStyle(fontSize: 15, fontWeight: FontWeight.w700,
    color: AppColors.primaryText);
  static const body = TextStyle(fontSize: 14, color: AppColors.secondaryText,
    height: 1.5);
  static const caption = TextStyle(fontSize: 12, fontWeight: FontWeight.w500,
    color: AppColors.secondaryText);
  static const amount = TextStyle(fontSize: 30, fontWeight: FontWeight.w800,
    color: AppColors.navy, letterSpacing: -.8);
  static const button = TextStyle(fontSize: 15, fontWeight: FontWeight.w700,
    color: AppColors.white);
}
