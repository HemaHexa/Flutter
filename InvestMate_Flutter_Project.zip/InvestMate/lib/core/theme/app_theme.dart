import 'package:flutter/material.dart';
import 'app_colors.dart';
import 'app_text_styles.dart';

class AppTheme {
  AppTheme._();
  static ThemeData get lightTheme => ThemeData(
    useMaterial3: true, brightness: Brightness.light,
    scaffoldBackgroundColor: AppColors.background,
    primaryColor: AppColors.teal, fontFamily: 'Roboto',
    colorScheme: const ColorScheme.light(primary: AppColors.teal,
      secondary: AppColors.seafoam, surface: AppColors.white,
      error: AppColors.negative),
    appBarTheme: const AppBarTheme(backgroundColor: AppColors.background,
      foregroundColor: AppColors.navy, elevation: 0),
    cardTheme: CardThemeData(color: AppColors.white, elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: AppColors.border)), margin: EdgeInsets.zero),
    elevatedButtonTheme: ElevatedButtonThemeData(style: ElevatedButton.styleFrom(
      backgroundColor: AppColors.teal, foregroundColor: AppColors.white,
      elevation: 0, padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      textStyle: AppTextStyles.button)),
    inputDecorationTheme: InputDecorationTheme(
      filled: true, fillColor: AppColors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(15),
        borderSide: const BorderSide(color: AppColors.border)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15),
        borderSide: const BorderSide(color: AppColors.border)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15),
        borderSide: const BorderSide(color: AppColors.teal, width: 1.5))),
    dividerColor: AppColors.divider,
  );
}
