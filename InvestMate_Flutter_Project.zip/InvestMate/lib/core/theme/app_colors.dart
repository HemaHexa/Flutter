import 'package:flutter/material.dart';

class AppColors {
  AppColors._();
  static const white = Color(0xFFFFFFFF);
  static const background = Color(0xFFF4F8F9);
  static const mist = Color(0xFFEAF3F4);
  static const navy = Color(0xFF183B48);
  static const deepNavy = Color(0xFF102D39);
  static const teal = Color(0xFF159A91);
  static const seafoam = Color(0xFFA6DCD5);
  static const lightTeal = Color(0xFFE1F4F1);
  static const primaryText = Color(0xFF183B48);
  static const secondaryText = Color(0xFF65758B);
  static const mutedText = Color(0xFF9AA8B5);
  static const positive = Color(0xFF199B70);
  static const negative = Color(0xFFE36B68);
  static const warning = Color(0xFFE9A23B);
  static const border = Color(0xFFE5ECEF);
  static const divider = Color(0xFFEDF1F3);
  static const oceanGradient = LinearGradient(
    begin: Alignment.topLeft, end: Alignment.bottomRight,
    colors: [white, Color(0xFFF0F8F8), Color(0xFFE1F4F1)]);
  static const tealGradient = LinearGradient(
    begin: Alignment.topLeft, end: Alignment.bottomRight,
    colors: [Color(0xFF159A91), Color(0xFF247B83)]);
}
