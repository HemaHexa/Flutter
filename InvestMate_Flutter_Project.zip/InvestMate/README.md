# InvestMate Flutter project

Frontend-only Flutter prototype using Ocean Luxe styling and illustrative mock data.

## Run
Open a terminal in this folder and run:
```bash
flutter create .
flutter pub get
flutter run
```
The archive contains all Dart source and project configuration. Flutter generates platform-specific folders (Android/iOS/Windows) on your machine. No third-party packages, API keys, backend, or database are required.

## Features
- Animated welcome screen
- Investment dashboard and mock portfolio summary
- AI-style assistant chat with local mock responses
- Holdings list and asset allocation
- Investment detail screen and illustrative sparkline
- Ocean Luxe theme, reusable widgets and mock data

All figures are illustrative and are not financial advice.
