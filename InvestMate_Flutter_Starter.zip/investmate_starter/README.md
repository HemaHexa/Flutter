# InvestMate Flutter starter

This ZIP contains the first UI implementation for the InvestMate conversational home experience.

## Included
- `lib/main.dart` — app entry point and dark theme.
- `lib/screens/home_screen.dart` — animated home orb, personal insight, suggestion chips, right-side carousel indicators, Wealth / Investments / Credit Health demo pages, bottom interaction dock and typing sheet.

## Install into your existing Flutter project
1. Extract this ZIP.
2. Copy the included `lib` folder into your existing Flutter project.
3. Allow it to merge with/replace the existing `lib/main.dart` and add `lib/screens/home_screen.dart`.
4. From the project root run:
   ```bash
   flutter pub get
   flutter run
   ```

No third-party packages are required.

## Notes
- All financial values are illustrative mock data.
- The central dock supports tap-to-open typing and a long-press recording visual state.
- Real speech-to-text is not connected yet. It requires a speech recognition package, Android/iOS permissions and platform setup.
- AI answers, account integrations, real financial data and transaction execution are not connected.
- This is a UI starter, not a production financial application.
