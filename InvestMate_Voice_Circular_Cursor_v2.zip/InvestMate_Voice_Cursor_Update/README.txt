INVESTMATE — CIRCULAR INDICATORS + VOICE INPUT UPDATE

This ZIP updates the existing modular InvestMate lib/ source.

CHANGES
1. Right-side section navigation indicators are now circular dots. The active
   section is a softly glowing teal circle instead of a vertical pill.
2. The bottom "Tap to type · Hold to speak" control is no longer inside a
   filled rounded rectangle. It is a clean, unboxed text-and-microphone control.
3. Tap the text area to open the typing composer.
4. Press and hold the control to start device speech recognition. Release to
   stop, convert the recognized speech to text, and send it to the AI demo chat.
5. While listening, the control displays a live listening state.

REQUIRED SETUP FOR VOICE RECOGNITION

A. Add this dependency under dependencies: in your existing pubspec.yaml:

  speech_to_text: ^7.4.0

Then run `flutter pub get`.

B. Add these permissions inside the top-level <manifest> element in:
   android/app/src/main/AndroidManifest.xml
   (place them above the <application> element):

  <uses-permission android:name="android.permission.RECORD_AUDIO"/>
  <uses-permission android:name="android.permission.INTERNET"/>

The app will request microphone permission at runtime when you first hold
the voice control.

INSTALL
1. Back up your current project.
2. Extract this ZIP.
3. Replace your project's entire lib folder with this ZIP's lib folder.
4. Keep pubspec.yaml and platform folders, but make the two configuration
   additions above.
5. Run:
   flutter clean
   flutter pub get
   flutter run -d emulator-5554

VOICE NOTES
- Speech recognition uses the device's native speech service. On an Android
  emulator, make sure a speech recognition service (usually the Google app)
  is installed/enabled and microphone input is available.
- If the emulator has no speech recognition service, test on a physical
  Android phone or enable/install the Google speech service in the emulator.
- Speech recognition is for short utterances; the OS may stop listening after
  a pause. Release the control to finish and send the recognized text.
- The app does not store or upload raw audio itself. The device speech service
  performs recognition; the resulting text is sent into the local demo chat.

All financial data and AI answers remain fictional demo content. The AI response
engine is still mock logic, not a live AI service.

The ZIP is integrity-checked but has not been compiled on your emulator.

6. The app now draws a custom glowing circular mouse pointer instead of the
   usual arrow while the pointer is inside the HomeScreen. This is intended
   for desktop/web mouse use; touch-only Android interaction will not display
   a pointer. Platform support for hiding the native arrow can vary.
