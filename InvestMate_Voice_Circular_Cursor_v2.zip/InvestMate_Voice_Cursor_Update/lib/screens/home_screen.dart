import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

part 'credit_health_screen.dart';
part 'investment_screen.dart';
part 'wealth_screen.dart';
part 'shared_widgets.dart';
part 'ai_conversation_screen.dart';

const Color _background = Color(0xFF10091B);
const Color _panel = Color(0xFF21152F);
const Color _muted = Color(0xFFB9A7CB);
const Color _lavender = Color(0xFFC18BFF);

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with TickerProviderStateMixin {
  late final AnimationController _orbController;
  late final AnimationController _pulseController;
  int _activePage = 0;
  bool _isRecording = false;
  bool _isTyping = false;
  final stt.SpeechToText _speech = stt.SpeechToText();
  String _voiceWords = '';
  int? _swipePointer;
  Offset? _swipeStart;
  Offset? _mousePosition;

  final List<_SectionData> _sections = const [
    _SectionData(
      title: 'Home',
      eyebrow: 'YOUR FINANCIAL COMPANION',
      subtitle: 'Your financial journey, made smarter.',
    ),
    _SectionData(
      title: 'Wealth',
      eyebrow: 'YOUR FINANCIAL POSITION',
      subtitle: 'See the bigger picture of your money.',
    ),
    _SectionData(
      title: 'Investments',
      eyebrow: 'YOUR INVESTMENT JOURNEY',
      subtitle: 'Understand how your money is performing.',
    ),
    _SectionData(
      title: 'Credit health',
      eyebrow: 'YOUR CREDIT PROFILE',
      subtitle: 'Understand the health of your credit.',
    ),
  ];

  @override
  void initState() {
    super.initState();
    _orbController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 7),
    )..repeat();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
      lowerBound: 0.96,
      upperBound: 1.04,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _orbController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  void _goToPage(int index) {
    if (index < 0 || index >= _sections.length) return;
    setState(() => _activePage = index);
  }

  void _openComposer() {
    setState(() => _isTyping = true);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF21152F),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (context) => _MessageComposer(
        onSend: (message) {
          Navigator.pop(context);
          setState(() => _isTyping = false);
          Navigator.of(this.context).push(
            MaterialPageRoute<void>(
              builder: (_) => _ConversationScreen(initialPrompt: message),
            ),
          );
        },
      ),
    ).whenComplete(() {
      if (mounted) setState(() => _isTyping = false);
    });
  }

  Future<void> _startVoice() async {
    if (_isRecording) return;
    setState(() {
      _isRecording = true;
      _voiceWords = '';
    });

    try {
      final available = await _speech.initialize(
        onError: (error) {
          if (!mounted) return;
          setState(() => _isRecording = false);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Voice recognition error: ${error.errorMsg}')),
          );
        },
      );
      if (!mounted) return;
      if (!available) {
        setState(() => _isRecording = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Speech recognition is unavailable. Check microphone permission and device speech services.'),
          ),
        );
        return;
      }
      await _speech.listen(
        onResult: (result) {
          if (!mounted) return;
          setState(() => _voiceWords = result.recognizedWords);
        },
      );
    } catch (error) {
      if (!mounted) return;
      setState(() => _isRecording = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not start voice input: $error')),
      );
    }
  }

  Future<void> _stopVoice() async {
    if (!_isRecording) return;
    await _speech.stop();
    // Give the platform recognizer a moment to deliver its final transcript.
    await Future<void>.delayed(const Duration(milliseconds: 250));
    if (!mounted) return;
    final transcript = _voiceWords.trim();
    setState(() => _isRecording = false);
    if (transcript.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('I did not catch that. Hold the voice control and try again.')),
      );
      return;
    }
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => _ConversationScreen(initialPrompt: transcript),
      ),
    );
  }

  void _showPlusActions() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF21152F),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 18, 22, 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Add to your conversation',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 18),
              _ActionRow(
                icon: Icons.insert_chart_outlined_rounded,
                title: 'Explore my finances',
                subtitle: 'Open a financial overview',
                onTap: () {
                  Navigator.pop(context);
                  _goToPage(1);
                },
              ),
              _ActionRow(
                icon: Icons.attach_file_rounded,
                title: 'Attach a file',
                subtitle: 'Connect documents in a future version',
                onTap: () => Navigator.pop(context),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final section = _sections[_activePage];

    return Scaffold(
      body: MouseRegion(
        // Hide the platform arrow where custom cursors are supported; draw
        // our own small circular pointer over the app instead.
        cursor: SystemMouseCursors.none,
        onHover: (event) => setState(() => _mousePosition = event.localPosition),
        onExit: (_) => setState(() => _mousePosition = null),
        child: Stack(
        children: [
          const _AmbientBackground(),
          SafeArea(
            child: Column(
              children: [
                _TopBar(
                  onHome: () => _goToPage(0),
                  isHome: _activePage == 0,
                ),
                Expanded(
                  // Listener observes the raw pointer sequence before child
                  // gesture recognizers compete in Flutter's gesture arena.
                  // This keeps the outer carousel swipe reliable even when
                  // the section contains tappable/scrollable controls.
                  child: Listener(
                    behavior: HitTestBehavior.translucent,
                    onPointerDown: (event) {
                      _swipePointer = event.pointer;
                      _swipeStart = event.position;
                    },
                    onPointerUp: (event) {
                      if (_swipePointer != event.pointer || _swipeStart == null) {
                        return;
                      }
                      final delta = event.position - _swipeStart!;
                      _swipePointer = null;
                      _swipeStart = null;
                      // Ignore vertical movement and short taps. A modest
                      // distance threshold works for both slow and fast swipes.
                      if (delta.dx.abs() < 55 ||
                          delta.dx.abs() < delta.dy.abs() * 1.25) {
                        return;
                      }
                      // RIGHT -> next; LEFT -> previous, with circular wrap.
                      if (delta.dx > 0) {
                        _goToPage((_activePage + 1) % _sections.length);
                      } else {
                        _goToPage((_activePage - 1 + _sections.length) %
                            _sections.length);
                      }
                    },
                    onPointerCancel: (event) {
                      if (_swipePointer == event.pointer) {
                        _swipePointer = null;
                        _swipeStart = null;
                      }
                    },
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 480),
                      switchInCurve: Curves.easeOutCubic,
                      switchOutCurve: Curves.easeInCubic,
                      transitionBuilder: (child, animation) {
                        final isNew = child.key == ValueKey(_activePage);
                        final begin = isNew
                            ? const Offset(0.12, 0)
                            : const Offset(-0.08, 0);
                        return FadeTransition(
                          opacity: animation,
                          child: SlideTransition(
                            position: Tween<Offset>(
                              begin: begin,
                              end: Offset.zero,
                            ).animate(animation),
                            child: child,
                          ),
                        );
                      },
                      child: _activePage == 0
                          ? _HomeContent(
                              key: const ValueKey(0),
                              orbController: _orbController,
                              pulseController: _pulseController,
                              onSuggestion: (value) {
                                final prompt = value.toLowerCase();
                                if (prompt.contains('wealth')) {
                                  _goToPage(1);
                                } else if (prompt.contains('investment')) {
                                  _goToPage(2);
                                } else if (prompt.contains('credit')) {
                                  _goToPage(3);
                                }
                              },
                            )
                          : _SectionContent(
                              key: ValueKey(_activePage),
                              index: _activePage,
                              section: section,
                              onPrompt: _openConversationPrompt,
                            ),
                    ),
                  ),
                ),
                _BottomDock(
                  isRecording: _isRecording,
                  onPlus: _showPlusActions,
                  onTap: _openComposer,
                  onLongPressStart: _startVoice,
                  onLongPressEnd: _stopVoice,
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
          Positioned(
            right: 9,
            top: MediaQuery.of(context).size.height * 0.39,
            child: _SectionIndicators(
              activeIndex: _activePage,
              onSelect: _goToPage,
            ),
          ),
          if (_mousePosition != null)
            Positioned(
              left: _mousePosition!.dx - 9,
              top: _mousePosition!.dy - 9,
              child: const IgnorePointer(
                child: _CircularMouseCursor(),
              ),
            ),
        ],
      ),
      ),
    );
  }

  void _openConversationPrompt(String prompt) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => _ConversationScreen(initialPrompt: prompt),
      ),
    );
  }

  void _openComposerWithPrompt(String prompt) {
    _openConversationPrompt(prompt);
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({required this.onHome, required this.isHome});
  final VoidCallback onHome;
  final bool isHome;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 12, 22, 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: onHome,
            child: const Row(
              children: [
                Icon(Icons.auto_awesome, color: _lavender, size: 23),
                SizedBox(width: 9),
                Text(
                  'InvestMate',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 19,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.2,
                  ),
                ),
              ],
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
            decoration: BoxDecoration(
              color: const Color(0xFF1C2B29).withOpacity(0.8),
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: const Color(0xFF31534A)),
            ),
            child: const Row(
              children: [
                Icon(Icons.circle, color: Color(0xFF65D6A1), size: 7),
                SizedBox(width: 6),
                Text(
                  'AI READY',
                  style: TextStyle(
                    color: Color(0xFFB9D9CA),
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _HomeContent extends StatelessWidget {
  const _HomeContent({
    super.key,
    required this.orbController,
    required this.pulseController,
    required this.onSuggestion,
  });

  final AnimationController orbController;
  final AnimationController pulseController;
  final ValueChanged<String> onSuggestion;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(24, 18, 35, 16),
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: constraints.maxHeight - 34),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 10),
                const Text(
                  'GOOD MORNING',
                  style: TextStyle(
                    color: _muted,
                    fontSize: 10,
                    letterSpacing: 2.1,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 9),
                const Text(
                  'Hello, Investor.',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 30,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.8,
                  ),
                ),
                const SizedBox(height: 7),
                const Text(
                  'Your financial journey, made smarter.',
                  style: TextStyle(color: _muted, fontSize: 14),
                ),
                const SizedBox(height: 18),
                Center(
                  child: AnimatedBuilder(
                    animation: Listenable.merge([orbController, pulseController]),
                    builder: (context, child) {
                      return Transform.scale(
                        scale: pulseController.value,
                        child: SizedBox(
                          width: 218,
                          height: 218,
                          child: CustomPaint(
                            painter: _OrbPainter(orbController.value),
                            child: const Center(
                              child: Icon(
                                Icons.auto_awesome_rounded,
                                color: Colors.white,
                                size: 43,
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const Center(
                  child: Text(
                    'YOUR AI COMPANION',
                    style: TextStyle(
                      color: Color(0xFFD2B9EC),
                      fontSize: 10,
                      letterSpacing: 2,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(17),
                  decoration: BoxDecoration(
                    color: _panel.withOpacity(0.88),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.white.withOpacity(0.07)),
                  ),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'A little progress worth noticing',
                        style: TextStyle(
                          color: _muted,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Your demo wealth grew 4.8% this month.',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          height: 1.35,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 5),
                      Text(
                        'Explore what changed in your financial picture.',
                        style: TextStyle(color: _muted, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 19),
                const Text(
                  'WHAT WOULD YOU LIKE TO EXPLORE?',
                  style: TextStyle(
                    color: _muted,
                    fontSize: 10,
                    letterSpacing: 1.3,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 11),
                SizedBox(
                  height: 42,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    physics: const BouncingScrollPhysics(),
                    children: [
                      _SuggestionChip(
                        label: 'My wealth',
                        icon: Icons.account_balance_wallet_outlined,
                        onTap: () => onSuggestion('Show me my wealth'),
                      ),
                      _SuggestionChip(
                        label: 'Investments',
                        icon: Icons.show_chart_rounded,
                        onTap: () => onSuggestion('How are my investments?'),
                      ),
                      _SuggestionChip(
                        label: 'Credit health',
                        icon: Icons.speed_rounded,
                        onTap: () => onSuggestion('Explain my credit health'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _SectionContent extends StatelessWidget {
  const _SectionContent({
    super.key,
    required this.index,
    required this.section,
    required this.onPrompt,
  });

  final int index;
  final _SectionData section;
  final ValueChanged<String> onPrompt;

  @override
  Widget build(BuildContext context) {
    if (index == 1) {
      return _WealthDetailScreen(section: section, onPrompt: onPrompt);
    }
    if (index == 2) {
      return _InvestmentDetailScreen(onPrompt: onPrompt);
    }
    if (index == 3) {
      return _CreditHealthScreen(onPrompt: onPrompt);
    }
    final isWealth = index == 1;
    final isInvestment = index == 2;
    final value = isWealth ? '₹8,45,250' : isInvestment ? '₹3,72,800' : '782';
    final label = isWealth
        ? 'TOTAL NET WORTH'
        : isInvestment
            ? 'PORTFOLIO VALUE'
            : 'DEMO CREDIT SCORE';
    final change = isWealth
        ? '+4.8% this month'
        : isInvestment
            ? '+8.6% overall returns'
            : 'Very good range';

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(24, 30, 38, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '0${index}  /  03  ·  ${section.eyebrow}',
            style: const TextStyle(
              color: _muted,
              fontSize: 9,
              letterSpacing: 1.3,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            section.title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 32,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 7),
          Text(section.subtitle, style: const TextStyle(color: _muted)),
          const SizedBox(height: 32),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF38204F), Color(0xFF21152F)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: _lavender.withOpacity(0.2)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(
                        color: _muted, fontSize: 10, letterSpacing: 1.5)),
                const SizedBox(height: 12),
                Text(
                  value,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 32,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 8),
                Text(change,
                    style: const TextStyle(
                        color: Color(0xFF79DDB0), fontSize: 13)),
                const SizedBox(height: 24),
                _MiniBars(seed: index),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _InfoRow(
            icon: isWealth
                ? Icons.account_balance_outlined
                : isInvestment
                    ? Icons.pie_chart_outline_rounded
                    : Icons.history_rounded,
            title: isWealth
                ? 'Assets and liabilities'
                : isInvestment
                    ? 'Portfolio allocation'
                    : 'Payment history',
            subtitle: 'Demo information for the wireframe',
          ),
          _InfoRow(
            icon: isWealth
                ? Icons.trending_up_rounded
                : isInvestment
                    ? Icons.insights_rounded
                    : Icons.credit_score_rounded,
            title: isWealth
                ? 'Wealth over time'
                : isInvestment
                    ? 'Investment performance'
                    : 'Credit utilization',
            subtitle: 'Tap into a conversation to explore this',
          ),
          const SizedBox(height: 18),
          Text(
            isWealth
                ? 'Ask about your net worth'
                : isInvestment
                    ? 'Ask about your portfolio'
                    : 'Ask about your credit profile',
            style: const TextStyle(
                color: Color(0xFFD7B9F4),
                fontSize: 14,
                fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}
