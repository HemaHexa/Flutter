import 'dart:math' as math;
import 'package:flutter/material.dart';

const Color _background = Color(0xFF10091B);
const Color _panel = Color(0xFF21152F);
const Color _muted = Color(0xFFB9A7CB);
const Color _lavender = Color(0xFFC18BFF);

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with TickerProviderStateMixin {
  late final AnimationController _orbController;
  late final AnimationController _pulseController;
  int _activePage = 0;
  bool _isRecording = false;
  bool _isTyping = false;

  final List<_SectionData> _sections = const [
    _SectionData(
      title: 'Home',
      eyebrow: 'YOUR FINANCIAL COMPANION',
      subtitle: 'Your financial journey, made smarter.',
    ),
    _SectionData(
      title: 'Wealth',
      eyebrow: 'YOUR FINANCIAL POSITION',
      subtitle: 'See the bigger picture of your money.',
    ),
    _SectionData(
      title: 'Investments',
      eyebrow: 'YOUR INVESTMENT JOURNEY',
      subtitle: 'Understand how your money is performing.',
    ),
    _SectionData(
      title: 'Credit health',
      eyebrow: 'YOUR CREDIT PROFILE',
      subtitle: 'Understand the health of your credit.',
    ),
  ];

  @override
  void initState() {
    super.initState();
    _orbController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 7),
    )..repeat();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
      lowerBound: 0.96,
      upperBound: 1.04,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _orbController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  void _goToPage(int index) {
    if (index < 0 || index >= _sections.length) return;
    setState(() => _activePage = index);
  }

  void _openComposer() {
    setState(() => _isTyping = true);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF21152F),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (context) => _MessageComposer(
        onSend: (message) {
          Navigator.pop(context);
          setState(() => _isTyping = false);
          Navigator.of(this.context).push(
            MaterialPageRoute<void>(
              builder: (_) => _ConversationScreen(initialPrompt: message),
            ),
          );
        },
      ),
    ).whenComplete(() {
      if (mounted) setState(() => _isTyping = false);
    });
  }

  void _startVoice() {
    setState(() => _isRecording = true);
  }

  void _stopVoice() {
    if (!_isRecording) return;
    setState(() => _isRecording = false);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Voice interaction preview. Speech-to-text will be connected next.',
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _showPlusActions() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF21152F),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 18, 22, 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Add to your conversation',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 18),
              _ActionRow(
                icon: Icons.insert_chart_outlined_rounded,
                title: 'Explore my finances',
                subtitle: 'Open a financial overview',
                onTap: () {
                  Navigator.pop(context);
                  _goToPage(1);
                },
              ),
              _ActionRow(
                icon: Icons.attach_file_rounded,
                title: 'Attach a file',
                subtitle: 'Connect documents in a future version',
                onTap: () => Navigator.pop(context),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final section = _sections[_activePage];

    return Scaffold(
      body: Stack(
        children: [
          const _AmbientBackground(),
          SafeArea(
            child: Column(
              children: [
                _TopBar(
                  onHome: () => _goToPage(0),
                  isHome: _activePage == 0,
                ),
                Expanded(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onHorizontalDragEnd: (details) {
                      final velocity = details.primaryVelocity ?? 0;
                      // Circular carousel:
                      // swipe RIGHT -> next section; swipe LEFT -> previous.
                      if (velocity > 180) {
                        _goToPage((_activePage + 1) % _sections.length);
                      } else if (velocity < -180) {
                        _goToPage((_activePage - 1 + _sections.length) %
                            _sections.length);
                      }
                    },
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 480),
                      switchInCurve: Curves.easeOutCubic,
                      switchOutCurve: Curves.easeInCubic,
                      transitionBuilder: (child, animation) {
                        final isNew = child.key == ValueKey(_activePage);
                        final begin = isNew
                            ? const Offset(0.12, 0)
                            : const Offset(-0.08, 0);
                        return FadeTransition(
                          opacity: animation,
                          child: SlideTransition(
                            position: Tween<Offset>(
                              begin: begin,
                              end: Offset.zero,
                            ).animate(animation),
                            child: child,
                          ),
                        );
                      },
                      child: _activePage == 0
                          ? _HomeContent(
                              key: const ValueKey(0),
                              orbController: _orbController,
                              pulseController: _pulseController,
                              onSuggestion: (value) {
                                final prompt = value.toLowerCase();
                                if (prompt.contains('wealth')) {
                                  _goToPage(1);
                                } else if (prompt.contains('investment')) {
                                  _goToPage(2);
                                } else if (prompt.contains('credit')) {
                                  _goToPage(3);
                                }
                              },
                            )
                          : _SectionContent(
                              key: ValueKey(_activePage),
                              index: _activePage,
                              section: section,
                            ),
                    ),
                  ),
                ),
                _BottomDock(
                  isRecording: _isRecording,
                  onPlus: _showPlusActions,
                  onTap: _openComposer,
                  onLongPressStart: _startVoice,
                  onLongPressEnd: _stopVoice,
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
          Positioned(
            right: 9,
            top: MediaQuery.of(context).size.height * 0.39,
            child: _SectionIndicators(
              activeIndex: _activePage,
              onSelect: _goToPage,
            ),
          ),
        ],
      ),
    );
  }

  void _openComposerWithPrompt(String prompt) {
    _openComposer();
    // The prompt is also surfaced as a confirmation so this starter remains
    // dependency-free. Wire it into the composer/backend in the next iteration.
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Selected: $prompt'),
        duration: const Duration(seconds: 1),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({required this.onHome, required this.isHome});
  final VoidCallback onHome;
  final bool isHome;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 12, 22, 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: onHome,
            child: const Row(
              children: [
                Icon(Icons.auto_awesome, color: _lavender, size: 23),
                SizedBox(width: 9),
                Text(
                  'InvestMate',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 19,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.2,
                  ),
                ),
              ],
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
            decoration: BoxDecoration(
              color: const Color(0xFF1C2B29).withOpacity(0.8),
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: const Color(0xFF31534A)),
            ),
            child: const Row(
              children: [
                Icon(Icons.circle, color: Color(0xFF65D6A1), size: 7),
                SizedBox(width: 6),
                Text(
                  'AI READY',
                  style: TextStyle(
                    color: Color(0xFFB9D9CA),
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _HomeContent extends StatelessWidget {
  const _HomeContent({
    super.key,
    required this.orbController,
    required this.pulseController,
    required this.onSuggestion,
  });

  final AnimationController orbController;
  final AnimationController pulseController;
  final ValueChanged<String> onSuggestion;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(24, 18, 35, 16),
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: constraints.maxHeight - 34),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 10),
                const Text(
                  'GOOD MORNING',
                  style: TextStyle(
                    color: _muted,
                    fontSize: 10,
                    letterSpacing: 2.1,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 9),
                const Text(
                  'Hello, Investor.',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 30,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.8,
                  ),
                ),
                const SizedBox(height: 7),
                const Text(
                  'Your financial journey, made smarter.',
                  style: TextStyle(color: _muted, fontSize: 14),
                ),
                const SizedBox(height: 18),
                Center(
                  child: AnimatedBuilder(
                    animation: Listenable.merge([orbController, pulseController]),
                    builder: (context, child) {
                      return Transform.scale(
                        scale: pulseController.value,
                        child: SizedBox(
                          width: 218,
                          height: 218,
                          child: CustomPaint(
                            painter: _OrbPainter(orbController.value),
                            child: const Center(
                              child: Icon(
                                Icons.auto_awesome_rounded,
                                color: Colors.white,
                                size: 43,
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const Center(
                  child: Text(
                    'YOUR AI COMPANION',
                    style: TextStyle(
                      color: Color(0xFFD2B9EC),
                      fontSize: 10,
                      letterSpacing: 2,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(17),
                  decoration: BoxDecoration(
                    color: _panel.withOpacity(0.88),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.white.withOpacity(0.07)),
                  ),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'A little progress worth noticing',
                        style: TextStyle(
                          color: _muted,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Your demo wealth grew 4.8% this month.',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          height: 1.35,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 5),
                      Text(
                        'Explore what changed in your financial picture.',
                        style: TextStyle(color: _muted, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 19),
                const Text(
                  'WHAT WOULD YOU LIKE TO EXPLORE?',
                  style: TextStyle(
                    color: _muted,
                    fontSize: 10,
                    letterSpacing: 1.3,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 11),
                SizedBox(
                  height: 42,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    physics: const BouncingScrollPhysics(),
                    children: [
                      _SuggestionChip(
                        label: 'My wealth',
                        icon: Icons.account_balance_wallet_outlined,
                        onTap: () => onSuggestion('Show me my wealth'),
                      ),
                      _SuggestionChip(
                        label: 'Investments',
                        icon: Icons.show_chart_rounded,
                        onTap: () => onSuggestion('How are my investments?'),
                      ),
                      _SuggestionChip(
                        label: 'Credit health',
                        icon: Icons.speed_rounded,
                        onTap: () => onSuggestion('Explain my credit health'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _SectionContent extends StatelessWidget {
  const _SectionContent({
    super.key,
    required this.index,
    required this.section,
  });

  final int index;
  final _SectionData section;

  @override
  Widget build(BuildContext context) {
    if (index == 1) {
      return _WealthDetailScreen(section: section);
    }
    final isWealth = index == 1;
    final isInvestment = index == 2;
    final value = isWealth ? '₹8,45,250' : isInvestment ? '₹3,72,800' : '782';
    final label = isWealth
        ? 'TOTAL NET WORTH'
        : isInvestment
            ? 'PORTFOLIO VALUE'
            : 'DEMO CREDIT SCORE';
    final change = isWealth
        ? '+4.8% this month'
        : isInvestment
            ? '+8.6% overall returns'
            : 'Very good range';

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(24, 30, 38, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '0${index}  /  03  ·  ${section.eyebrow}',
            style: const TextStyle(
              color: _muted,
              fontSize: 9,
              letterSpacing: 1.3,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            section.title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 32,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 7),
          Text(section.subtitle, style: const TextStyle(color: _muted)),
          const SizedBox(height: 32),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF38204F), Color(0xFF21152F)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: _lavender.withOpacity(0.2)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(
                        color: _muted, fontSize: 10, letterSpacing: 1.5)),
                const SizedBox(height: 12),
                Text(
                  value,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 32,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 8),
                Text(change,
                    style: const TextStyle(
                        color: Color(0xFF79DDB0), fontSize: 13)),
                const SizedBox(height: 24),
                _MiniBars(seed: index),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _InfoRow(
            icon: isWealth
                ? Icons.account_balance_outlined
                : isInvestment
                    ? Icons.pie_chart_outline_rounded
                    : Icons.history_rounded,
            title: isWealth
                ? 'Assets and liabilities'
                : isInvestment
                    ? 'Portfolio allocation'
                    : 'Payment history',
            subtitle: 'Demo information for the wireframe',
          ),
          _InfoRow(
            icon: isWealth
                ? Icons.trending_up_rounded
                : isInvestment
                    ? Icons.insights_rounded
                    : Icons.credit_score_rounded,
            title: isWealth
                ? 'Wealth over time'
                : isInvestment
                    ? 'Investment performance'
                    : 'Credit utilization',
            subtitle: 'Tap into a conversation to explore this',
          ),
          const SizedBox(height: 18),
          Text(
            isWealth
                ? 'Ask about your net worth'
                : isInvestment
                    ? 'Ask about your portfolio'
                    : 'Ask about your credit profile',
            style: const TextStyle(
                color: Color(0xFFD7B9F4),
                fontSize: 14,
                fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}



class _WealthDetailScreen extends StatefulWidget {
  const _WealthDetailScreen({required this.section});
  final _SectionData section;

  @override
  State<_WealthDetailScreen> createState() => _WealthDetailScreenState();
}

class _WealthDetailScreenState extends State<_WealthDetailScreen> {
  String _period = '6M';

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(24, 26, 38, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('01 / 03  ·  YOUR FINANCIAL POSITION',
              style: TextStyle(color: _muted, fontSize: 9, letterSpacing: 1.2,
                  fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          const Text('My Wealth', style: TextStyle(color: Colors.white,
              fontSize: 32, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          const Text('Your complete financial picture, in one place.',
              style: TextStyle(color: _muted, fontSize: 13)),
          const SizedBox(height: 20),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(19),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF48235F), Color(0xFF21152F)],
                begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(23),
              border: Border.all(color: _lavender.withOpacity(0.24)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('TOTAL NET WORTH',
                    style: TextStyle(color: _muted, fontSize: 10,
                        letterSpacing: 1.4, fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                const Text('₹8,45,250',
                    style: TextStyle(color: Colors.white, fontSize: 30,
                        fontWeight: FontWeight.w700)),
                const SizedBox(height: 5),
                const Text('↗ 4.8% this month',
                    style: TextStyle(color: Color(0xFF79DDB0), fontSize: 12)),
                const SizedBox(height: 18),
                Row(
                  children: const [
                    Expanded(child: _WealthMiniStat(
                        label: 'TOTAL ASSETS', value: '₹10,25,000')),
                    SizedBox(width: 12),
                    Expanded(child: _WealthMiniStat(
                        label: 'LIABILITIES', value: '₹1,79,750')),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 23),
          const Text('WEALTH GROWTH',
              style: TextStyle(color: _muted, fontSize: 10,
                  letterSpacing: 1.3, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.fromLTRB(15, 15, 15, 12),
            decoration: BoxDecoration(
              color: _panel.withOpacity(0.82),
              borderRadius: BorderRadius.circular(19),
              border: Border.all(color: Colors.white.withOpacity(0.06)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('₹8,45,250',
                    style: const TextStyle(color: Colors.white,
                        fontSize: 20, fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                const Text('Illustrative net worth trend',
                    style: TextStyle(color: _muted, fontSize: 10)),
                const SizedBox(height: 12),
                SizedBox(height: 95, child: _WealthLineChart(period: _period)),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: ['1M', '3M', '6M', '1Y'].map((period) {
                    final selected = _period == period;
                    return GestureDetector(
                      onTap: () => setState(() => _period = period),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 13, vertical: 7),
                        decoration: BoxDecoration(
                          color: selected
                              ? const Color(0xFF69418B)
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(period, style: TextStyle(
                          color: selected ? Colors.white : _muted,
                          fontSize: 10, fontWeight: FontWeight.w600)),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
          const SizedBox(height: 23),
          const Text('WHERE YOUR MONEY IS',
              style: TextStyle(color: _muted, fontSize: 10,
                  letterSpacing: 1.3, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          const _WealthBreakdownRow(
            icon: Icons.account_balance_outlined,
            title: 'Bank balance', subtitle: 'Savings and current accounts',
            amount: '₹2,50,000', percent: '24%', fraction: 0.24,
            tint: Color(0xFFB98BFF)),
          const _WealthBreakdownRow(
            icon: Icons.trending_up_rounded,
            title: 'Investments', subtitle: 'Stocks and mutual funds',
            amount: '₹3,72,800', percent: '36%', fraction: 0.36,
            tint: Color(0xFF65C9D3)),
          const _WealthBreakdownRow(
            icon: Icons.lock_outline_rounded,
            title: 'Fixed deposits', subtitle: 'Long-term deposits',
            amount: '₹2,80,000', percent: '27%', fraction: 0.27,
            tint: Color(0xFFDBA0FF)),
          const _WealthBreakdownRow(
            icon: Icons.savings_outlined,
            title: 'Other assets', subtitle: 'Additional holdings',
            amount: '₹1,22,200', percent: '13%', fraction: 0.13,
            tint: Color(0xFF7ADDAA)),
          const SizedBox(height: 20),
          const Text('LIABILITIES',
              style: TextStyle(color: _muted, fontSize: 10,
                  letterSpacing: 1.3, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          const _WealthBreakdownRow(
            icon: Icons.credit_card_rounded,
            title: 'Outstanding dues', subtitle: 'Loans and credit balances',
            amount: '₹1,79,750', percent: '100%', fraction: 1,
            tint: Color(0xFFE59BBD), compact: true),
          const SizedBox(height: 15),
          const Text('ASK INVESTMATE',
              style: TextStyle(color: _muted, fontSize: 10,
                  letterSpacing: 1.3, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            _WealthPromptChip(label: 'Explain my assets'),
            _WealthPromptChip(label: 'How has my wealth grown?'),
            _WealthPromptChip(label: 'Review my liabilities'),
          ]),
          const SizedBox(height: 12),
          const Text('All figures are illustrative mock data.',
              style: TextStyle(color: _muted, fontSize: 9)),
        ],
      ),
    );
  }
}

class _WealthMiniStat extends StatelessWidget {
  const _WealthMiniStat({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(11),
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(0.06),
      borderRadius: BorderRadius.circular(13)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(color: _muted, fontSize: 8,
          letterSpacing: 0.8)),
      const SizedBox(height: 5),
      FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft,
        child: Text(value, style: const TextStyle(color: Colors.white,
            fontSize: 15, fontWeight: FontWeight.w700))),
    ]),
  );
}

class _WealthBreakdownRow extends StatelessWidget {
  const _WealthBreakdownRow({
    required this.icon, required this.title, required this.subtitle,
    required this.amount, required this.percent, required this.fraction,
    required this.tint, this.compact = false,
  });
  final IconData icon;
  final String title, subtitle, amount, percent;
  final double fraction;
  final Color tint;
  final bool compact;

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 9),
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: _panel.withOpacity(0.78),
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: Colors.white.withOpacity(0.055))),
    child: Row(children: [
      SizedBox(width: 54, height: 54, child: Stack(alignment: Alignment.center,
        children: [
          SizedBox.expand(child: CircularProgressIndicator(
            value: fraction, strokeWidth: 5,
            backgroundColor: Colors.white.withOpacity(0.08),
            valueColor: AlwaysStoppedAnimation<Color>(tint))),
          Icon(icon, color: tint, size: 20),
        ])),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: Colors.white,
              fontSize: 12, fontWeight: FontWeight.w600)),
          const SizedBox(height: 3),
          Text(subtitle, style: const TextStyle(color: _muted, fontSize: 9)),
        ])),
      const SizedBox(width: 6),
      Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Text(amount, style: const TextStyle(color: Colors.white,
            fontSize: 13, fontWeight: FontWeight.w700)),
        const SizedBox(height: 3),
        Text(percent, style: TextStyle(color: tint, fontSize: 10,
            fontWeight: FontWeight.w600)),
      ]),
    ]),
  );
}

class _WealthLineChart extends StatelessWidget {
  const _WealthLineChart({required this.period});
  final String period;

  @override
  Widget build(BuildContext context) => CustomPaint(
    painter: _WealthChartPainter(period),
    child: const SizedBox.expand(),
  );
}

class _WealthChartPainter extends CustomPainter {
  _WealthChartPainter(this.period);
  final String period;

  @override
  void paint(Canvas canvas, Size size) {
    final values = period == '1M'
        ? [0.72, 0.67, 0.76, 0.70, 0.81, 0.75, 0.88, 0.84]
        : period == '3M'
            ? [0.48, 0.57, 0.52, 0.65, 0.61, 0.75, 0.71, 0.88]
            : period == '1Y'
                ? [0.25, 0.32, 0.29, 0.44, 0.50, 0.59, 0.72, 0.88]
                : [0.40, 0.48, 0.43, 0.61, 0.56, 0.69, 0.76, 0.88];
    final path = Path();
    for (var i = 0; i < values.length; i++) {
      final point = Offset(
        size.width * i / (values.length - 1),
        size.height * (1 - values[i]),
      );
      if (i == 0) {
        path.moveTo(point.dx, point.dy);
      } else {
        final previous = Offset(
          size.width * (i - 1) / (values.length - 1),
          size.height * (1 - values[i - 1]),
        );
        final mid = (previous.dx + point.dx) / 2;
        path.cubicTo(mid, previous.dy, mid, point.dy, point.dx, point.dy);
      }
    }
    final line = Paint()
      ..color = const Color(0xFFC18BFF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(path, line);
    final fill = Path.from(path)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    final fillPaint = Paint()
      ..shader = const LinearGradient(
        colors: [Color(0x66B77AFF), Color(0x00100A1B)],
        begin: Alignment.topCenter, end: Alignment.bottomCenter,
      ).createShader(Offset.zero & size);
    canvas.drawPath(fill, fillPaint);
  }

  @override
  bool shouldRepaint(covariant _WealthChartPainter oldDelegate) =>
      oldDelegate.period != period;
}

class _WealthPromptChip extends StatelessWidget {
  const _WealthPromptChip({required this.label});
  final String label;

  @override
  Widget build(BuildContext context) => ActionChip(
    onPressed: () {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Next conversation: $label')),
      );
    },
    backgroundColor: const Color(0xFF30203F),
    side: BorderSide(color: _lavender.withOpacity(0.2)),
    label: Text(label, style: const TextStyle(color: Colors.white, fontSize: 10)),
  );
}

class _MiniBars extends StatelessWidget {
  const _MiniBars({required this.seed});
  final int seed;

  @override
  Widget build(BuildContext context) {
    final heights = seed == 1
        ? [25.0, 36.0, 30.0, 48.0, 42.0, 57.0, 68.0, 61.0]
        : seed == 2
            ? [28.0, 34.0, 26.0, 45.0, 39.0, 58.0, 51.0, 72.0]
            : [42.0, 47.0, 39.0, 52.0, 45.0, 61.0, 56.0, 66.0];
    return SizedBox(
      height: 76,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: heights.map((height) {
          return Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Container(
                height: height,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  gradient: const LinearGradient(
                    colors: [Color(0xFFDB9AFF), Color(0xFF7041A4)],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

class _BottomDock extends StatelessWidget {
  const _BottomDock({
    required this.isRecording,
    required this.onPlus,
    required this.onTap,
    required this.onLongPressStart,
    required this.onLongPressEnd,
  });

  final bool isRecording;
  final VoidCallback onPlus;
  final VoidCallback onTap;
  final VoidCallback onLongPressStart;
  final VoidCallback onLongPressEnd;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(17, 8, 17, 0),
      child: Row(
        children: [
          Material(
            color: const Color(0xFF281A38),
            shape: const CircleBorder(),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: onPlus,
              child: const SizedBox(
                width: 48,
                height: 48,
                child: Icon(Icons.add_rounded, color: Color(0xFFD7B5F5)),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: GestureDetector(
              onTap: onTap,
              onLongPressStart: (_) => onLongPressStart(),
              onLongPressEnd: (_) => onLongPressEnd(),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                height: 52,
                decoration: BoxDecoration(
                  color: isRecording
                      ? const Color(0xFF55306F)
                      : const Color(0xFF281A38),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(
                    color: isRecording ? _lavender : Colors.white12,
                    width: isRecording ? 1.4 : 0.8,
                  ),
                  boxShadow: isRecording
                      ? [
                          BoxShadow(
                            color: _lavender.withOpacity(0.25),
                            blurRadius: 18,
                            spreadRadius: 1,
                          )
                        ]
                      : null,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      isRecording ? Icons.graphic_eq : Icons.edit_outlined,
                      color: const Color(0xFFD9B8F6),
                      size: 17,
                    ),
                    const SizedBox(width: 9),
                    Text(
                      isRecording
                          ? 'Listening… release to finish'
                          : 'Tap to type · Hold to speak',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionIndicators extends StatelessWidget {
  const _SectionIndicators({
    required this.activeIndex,
    required this.onSelect,
  });

  final int activeIndex;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(4, (index) {
        final active = activeIndex == index;
        return GestureDetector(
          onTap: () => onSelect(index),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            margin: const EdgeInsets.symmetric(vertical: 7),
            width: 7,
            height: active ? 25 : 7,
            decoration: BoxDecoration(
              color: active ? _lavender : const Color(0xFF665174),
              borderRadius: BorderRadius.circular(20),
              boxShadow: active
                  ? [
                      BoxShadow(
                        color: _lavender.withOpacity(0.65),
                        blurRadius: 12,
                      )
                    ]
                  : null,
            ),
          ),
        );
      }),
    );
  }
}

class _SuggestionChip extends StatelessWidget {
  const _SuggestionChip({
    required this.label,
    required this.icon,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ActionChip(
        onPressed: onTap,
        avatar: Icon(icon, size: 16, color: const Color(0xFFD6B5F4)),
        label: Text(label),
        backgroundColor: const Color(0xFF281A38),
        side: BorderSide(color: Colors.white.withOpacity(0.08)),
        labelStyle: const TextStyle(color: Colors.white, fontSize: 11),
        shape: const StadiumBorder(),
      ),
    );
  }
}

class _MessageComposer extends StatefulWidget {
  const _MessageComposer({required this.onSend});
  final ValueChanged<String> onSend;

  @override
  State<_MessageComposer> createState() => _MessageComposerState();
}

class _MessageComposerState extends State<_MessageComposer> {
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.fromLTRB(
          20,
          20,
          20,
          18 + MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'What would you like to know?',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _controller,
              autofocus: true,
              minLines: 1,
              maxLines: 4,
              textInputAction: TextInputAction.send,
              onSubmitted: (value) {
                if (value.trim().isNotEmpty) widget.onSend(value.trim());
              },
              decoration: InputDecoration(
                hintText: 'Ask InvestMate anything…',
                filled: true,
                fillColor: const Color(0xFF352342),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide.none,
                ),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.arrow_upward_rounded),
                  onPressed: () {
                    final value = _controller.text.trim();
                    if (value.isNotEmpty) widget.onSend(value);
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionRow extends StatelessWidget {
  const _ActionRow({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: CircleAvatar(
        backgroundColor: const Color(0xFF39264C),
        child: Icon(icon, color: _lavender),
      ),
      title: Text(title),
      subtitle: Text(subtitle, style: const TextStyle(color: _muted)),
      onTap: onTap,
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: _panel.withOpacity(0.75),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Row(
        children: [
          Icon(icon, color: _lavender, size: 22),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        color: Colors.white, fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                Text(subtitle,
                    style: const TextStyle(color: _muted, fontSize: 11)),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded, color: _muted),
        ],
      ),
    );
  }
}

class _SectionData {
  const _SectionData({
    required this.title,
    required this.eyebrow,
    required this.subtitle,
  });

  final String title;
  final String eyebrow;
  final String subtitle;
}

class _AmbientBackground extends StatelessWidget {
  const _AmbientBackground();

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: IgnorePointer(
        child: Stack(
          children: [
            Positioned(
              top: -130,
              left: -110,
              child: _GlowBlob(
                size: 290,
                color: const Color(0xFF59257E).withOpacity(0.28),
              ),
            ),
            Positioned(
              top: 250,
              right: -170,
              child: _GlowBlob(
                size: 310,
                color: const Color(0xFF302D78).withOpacity(0.17),
              ),
            ),
            Positioned(
              bottom: -180,
              left: 30,
              child: _GlowBlob(
                size: 300,
                color: const Color(0xFF6A287D).withOpacity(0.15),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GlowBlob extends StatelessWidget {
  const _GlowBlob({required this.size, required this.color});
  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(color: color, blurRadius: 100, spreadRadius: 35),
        ],
      ),
    );
  }
}

class _OrbPainter extends CustomPainter {
  _OrbPainter(this.progress);
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width * 0.34;
    final rotation = progress * math.pi * 2;

    final outer = Paint()
      ..shader = RadialGradient(
        colors: [
          const Color(0xFFB97BEE).withOpacity(0.05),
          const Color(0xFF9C54D5).withOpacity(0.24),
          const Color(0xFF572A82).withOpacity(0.02),
          Colors.transparent,
        ],
        stops: const [0, 0.48, 0.78, 1],
      ).createShader(Rect.fromCircle(center: center, radius: size.width * 0.49));
    canvas.drawCircle(center, size.width * 0.49, outer);

    final core = Paint()
      ..shader = const RadialGradient(
        center: Alignment(-0.35, -0.45),
        colors: [
          Color(0xFFE4B8FF),
          Color(0xFFB56DE9),
          Color(0xFF783CB1),
          Color(0xFF351A58),
        ],
        stops: [0, 0.28, 0.68, 1],
      ).createShader(Rect.fromCircle(center: center, radius: radius));
    canvas.drawCircle(center, radius, core);

    final ringPaint = Paint()
      ..color = const Color(0xFFDDB7FF).withOpacity(0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;
    canvas.drawCircle(center, radius + 13, ringPaint);

    final orbitPaint = Paint()
      ..color = const Color(0xFFEDCFFF).withOpacity(0.8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius + 21),
      rotation,
      math.pi * 0.75,
      false,
      orbitPaint,
    );

    final dotAngle = rotation * 1.7;
    final dot = Offset(
      center.dx + math.cos(dotAngle) * (radius + 21),
      center.dy + math.sin(dotAngle) * (radius + 21),
    );
    canvas.drawCircle(
      dot,
      4,
      Paint()..color = const Color(0xFFF0D9FF),
    );
  }

  @override
  bool shouldRepaint(covariant _OrbPainter oldDelegate) =>
      oldDelegate.progress != progress;
}


// Conversational response prototype. All figures and responses are mock data.
class _ConversationScreen extends StatefulWidget {
  const _ConversationScreen({required this.initialPrompt});
  final String initialPrompt;

  @override
  State<_ConversationScreen> createState() => _ConversationScreenState();
}

class _ConversationScreenState extends State<_ConversationScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _thinkingController;
  bool _thinking = true;
  final List<_ChatMessage> _messages = [];
  final TextEditingController _inputController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _thinkingController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..repeat(reverse: true);
    _messages.add(_ChatMessage(widget.initialPrompt, true));
    _generateMockAnswer(widget.initialPrompt);
  }

  Future<void> _generateMockAnswer(String prompt) async {
    await Future.delayed(const Duration(milliseconds: 1700));
    if (!mounted) return;
    setState(() {
      _thinking = false;
      _messages.add(_ChatMessage(_answerFor(prompt), false));
    });
  }

  String _answerFor(String prompt) {
    final q = prompt.toLowerCase();
    if (q.contains('credit') || q.contains('score')) {
      return 'Your demo credit profile is in a healthy range. Your sample score is 782. Keep repayments on time and avoid using too much of your available credit. These are illustrative values, not a real credit report.';
    }
    if (q.contains('investment') || q.contains('portfolio') || q.contains('stock')) {
      return 'Your demo investment portfolio is valued at ₹3,72,800, with an illustrative overall return of 8.6%. Your portfolio is spread across equity funds and individual stocks. We can explore allocation and performance next.';
    }
    return 'Here is your demo financial snapshot: estimated net worth ₹8,45,250, with sample wealth growth of 4.8% this month. Your next useful step is to review your investments and understand how each asset contributes to your overall wealth. These figures are mock data.';
  }

  void _sendFollowUp() {
    final text = _inputController.text.trim();
    if (text.isEmpty || _thinking) return;
    _inputController.clear();
    setState(() {
      _messages.add(_ChatMessage(text, true));
      _thinking = true;
    });
    _generateMockAnswer(text);
  }

  @override
  void dispose() {
    _thinkingController.dispose();
    _inputController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _background,
      appBar: AppBar(
        backgroundColor: _background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 19),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Row(
          children: [
            Icon(Icons.auto_awesome, color: _lavender, size: 20),
            SizedBox(width: 9),
            Text('InvestMate', style: TextStyle(fontWeight: FontWeight.w700)),
          ],
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 18),
            child: Center(
              child: Text('DEMO AI', style: TextStyle(color: _muted, fontSize: 10, letterSpacing: 1.2)),
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          const _AmbientBackground(),
          Column(
            children: [
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 20),
                  itemCount: _messages.length + (_thinking ? 1 : 0),
                  itemBuilder: (context, index) {
                    if (index == _messages.length) return _ThinkingIndicator(controller: _thinkingController);
                    final message = _messages[index];
                    return _ChatBubble(message: message);
                  },
                ),
              ),
              if (!_thinking)
                SizedBox(
                  height: 45,
                  child: ListView(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    scrollDirection: Axis.horizontal,
                    children: [
                      _SuggestionChip(label: 'Explore investments', icon: Icons.show_chart, onTap: () => _addPrompt('Explain my investment portfolio')),
                      _SuggestionChip(label: 'Check credit health', icon: Icons.speed, onTap: () => _addPrompt('How can I improve my credit score?')),
                    ],
                  ),
                ),
              SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(14, 9, 14, 12),
                  child: Row(
                    children: [
                      Container(
                        width: 44, height: 44,
                        decoration: const BoxDecoration(color: _panel, shape: BoxShape.circle),
                        child: const Icon(Icons.add, color: _lavender),
                      ),
                      const SizedBox(width: 9),
                      Expanded(
                        child: TextField(
                          controller: _inputController,
                          textInputAction: TextInputAction.send,
                          onSubmitted: (_) => _sendFollowUp(),
                          decoration: InputDecoration(
                            hintText: 'Continue the conversation…',
                            filled: true,
                            fillColor: _panel,
                            contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none),
                            suffixIcon: IconButton(
                              onPressed: _sendFollowUp,
                              icon: const Icon(Icons.arrow_upward_rounded, color: _lavender),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _addPrompt(String prompt) {
    setState(() {
      _messages.add(_ChatMessage(prompt, true));
      _thinking = true;
    });
    _generateMockAnswer(prompt);
  }
}

class _ChatMessage {
  const _ChatMessage(this.text, this.isUser);
  final String text;
  final bool isUser;
}

class _ChatBubble extends StatelessWidget {
  const _ChatBubble({required this.message});
  final _ChatMessage message;

  @override
  Widget build(BuildContext context) {
    final user = message.isUser;
    return Align(
      alignment: user ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.84),
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: user ? const Color(0xFF493064) : const Color(0xFF241731),
          borderRadius: BorderRadius.circular(20),
          border: user ? null : Border.all(color: _lavender.withOpacity(0.13)),
        ),
        child: user
            ? Text(message.text, style: const TextStyle(color: Colors.white, fontSize: 14, height: 1.45))
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(children: [Icon(Icons.auto_awesome, color: _lavender, size: 17), SizedBox(width: 7), Text('INVESTMATE INSIGHT', style: TextStyle(color: _muted, fontSize: 9, letterSpacing: 1.2, fontWeight: FontWeight.w700))]),
                  const SizedBox(height: 12),
                  Text(message.text, style: const TextStyle(color: Colors.white, fontSize: 14, height: 1.55)),
                  const SizedBox(height: 14),
                  _MockFinancialVisual(answer: message.text),
                  const SizedBox(height: 12),
                  const Text('Illustrative mock information', style: TextStyle(color: _muted, fontSize: 10)),
                ],
              ),
      ),
    );
  }
}

class _ThinkingIndicator extends StatelessWidget {
  const _ThinkingIndicator({required this.controller});
  final AnimationController controller;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, child) => Padding(
        padding: const EdgeInsets.only(bottom: 18),
        child: Row(
          children: [
            Container(
              width: 34, height: 34,
              decoration: BoxDecoration(shape: BoxShape.circle, color: _lavender.withOpacity(0.12), boxShadow: [BoxShadow(color: _lavender.withOpacity(0.2 + controller.value * 0.25), blurRadius: 18)]),
              child: const Icon(Icons.auto_awesome, color: _lavender, size: 18),
            ),
            const SizedBox(width: 10),
            Text('InvestMate is analysing your finances…', style: TextStyle(color: _muted.withOpacity(0.65 + controller.value * 0.35), fontSize: 12)),
            const SizedBox(width: 8),
            const SizedBox(width: 13, height: 13, child: CircularProgressIndicator(strokeWidth: 1.5, color: _lavender)),
          ],
        ),
      ),
    );
  }
}


class _MockFinancialVisual extends StatelessWidget {
  const _MockFinancialVisual({required this.answer});
  final String answer;

  @override
  Widget build(BuildContext context) {
    final q = answer.toLowerCase();
    if (q.contains('credit') || q.contains('score')) {
      return const _MetricVisual(
        title: 'Credit health',
        label: 'DEMO CREDIT SCORE',
        value: '782',
        detail: 'Very good',
        percentage: 0.78,
        amountLabel: '78% score indicator',
        color: Color(0xFF70DDAA),
        secondaryLabel: 'Credit utilization',
        secondaryValue: '24%',
      );
    }
    if (q.contains('investment') || q.contains('portfolio') || q.contains('stock')) {
      return const _MetricVisual(
        title: 'Investment overview',
        label: 'PORTFOLIO VALUE',
        value: '₹3,72,800',
        detail: '+8.6% illustrative returns',
        percentage: 0.68,
        amountLabel: '68% allocation view',
        color: Color(0xFF65C9D3),
        secondaryLabel: 'Invested amount',
        secondaryValue: '₹3,43,300',
      );
    }
    return const _MetricVisual(
      title: 'Wealth overview',
      label: 'DEMO NET WORTH',
      value: '₹8,45,250',
      detail: '+4.8% this month',
      percentage: 0.75,
      amountLabel: '75% progress illustration',
      color: Color(0xFFC18BFF),
      secondaryLabel: 'Assets',
      secondaryValue: '₹10,25,000',
    );
  }
}

class _MetricVisual extends StatelessWidget {
  const _MetricVisual({
    required this.title,
    required this.label,
    required this.value,
    required this.detail,
    required this.percentage,
    required this.amountLabel,
    required this.color,
    required this.secondaryLabel,
    required this.secondaryValue,
  });

  final String title;
  final String label;
  final String value;
  final String detail;
  final double percentage;
  final String amountLabel;
  final Color color;
  final String secondaryLabel;
  final String secondaryValue;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: const Color(0xFF30203F),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: color.withOpacity(0.22)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title.toUpperCase(),
              style: const TextStyle(
                color: _muted,
                fontSize: 9,
                letterSpacing: 1.2,
                fontWeight: FontWeight.w700,
              )),
          const SizedBox(height: 12),
          Row(
            children: [
              SizedBox(
                width: 76,
                height: 76,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox.expand(
                      child: CircularProgressIndicator(
                        value: percentage,
                        strokeWidth: 7,
                        backgroundColor: Colors.white.withOpacity(0.08),
                        valueColor: AlwaysStoppedAnimation<Color>(color),
                      ),
                    ),
                    Text('${(percentage * 100).round()}%',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                        )),
                  ],
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label,
                        style: const TextStyle(color: _muted, fontSize: 9)),
                    const SizedBox(height: 4),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Text(value,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 22,
                            fontWeight: FontWeight.w700,
                          )),
                    ),
                    const SizedBox(height: 5),
                    Text(detail,
                        style: TextStyle(
                          color: color,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        )),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Divider(color: Colors.white.withOpacity(0.08), height: 1),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(secondaryLabel,
                    style: const TextStyle(color: _muted, fontSize: 10)),
              ),
              Text(secondaryValue,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  )),
            ],
          ),
          const SizedBox(height: 5),
          Text(amountLabel,
              style: const TextStyle(color: _muted, fontSize: 9)),
        ],
      ),
    );
  }
}
