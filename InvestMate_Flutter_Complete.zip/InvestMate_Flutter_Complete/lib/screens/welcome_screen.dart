import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';
import 'chat_screen.dart';
class WelcomeScreen extends StatelessWidget {
 const WelcomeScreen({super.key});
 @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:Padding(padding:const EdgeInsets.all(26),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
 const Spacer(),Container(width:66,height:66,decoration:BoxDecoration(color:AppColors.softBlue,borderRadius:BorderRadius.circular(20)),child:const Icon(CupertinoIcons.chart_line_uptrend_xyaxis,color:AppColors.blue,size:34)),
 const SizedBox(height:26),const Text('InvestMate',style:TextStyle(color:AppColors.navy,fontSize:36,fontWeight:FontWeight.w800)),
 const SizedBox(height:12),const Text('Your investments, made easier to understand.',style:TextStyle(color:AppColors.slate,fontSize:17,height:1.5)),
 const SizedBox(height:30),Container(width:double.infinity,padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:AppColors.white,borderRadius:BorderRadius.circular(22),border:Border.all(color:AppColors.border)),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('A clearer view of your money',style:TextStyle(color:AppColors.navy,fontWeight:FontWeight.w700,fontSize:16)),SizedBox(height:8),Text('Ask questions, explore your portfolio and understand your investment performance through a simple conversation.',style:TextStyle(color:AppColors.slate,height:1.5,fontSize:13))])),
 const Spacer(),SizedBox(width:double.infinity,height:54,child:FilledButton(onPressed:()=>Navigator.of(context).push(CupertinoPageRoute(builder:(_)=>const ChatScreen())),style:FilledButton.styleFrom(backgroundColor:AppColors.blue,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16))),child:const Text('Get started',style:TextStyle(fontWeight:FontWeight.w700)))),
 const SizedBox(height:12),const Center(child:Text('Demo experience • Mock investment data',style:TextStyle(color:AppColors.slate,fontSize:11)))
 ])))));
}
