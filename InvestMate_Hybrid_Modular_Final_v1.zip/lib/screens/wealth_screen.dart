part of 'home_screen.dart';

class _WealthDetailScreen extends StatefulWidget {
  const _WealthDetailScreen({required this.section, required this.onPrompt});
  final _SectionData section;
  final ValueChanged<String> onPrompt;

  @override
  State<_WealthDetailScreen> createState() => _WealthDetailScreenState();
}

class _WealthDetailScreenState extends State<_WealthDetailScreen> {
  String _period = '6M';

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(24, 26, 38, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('01 / 03  ·  YOUR FINANCIAL POSITION',
              style: TextStyle(color: _muted, fontSize: 9, letterSpacing: 1.2,
                  fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          const Text('My Wealth', style: TextStyle(color: Colors.white,
              fontSize: 32, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          const Text('Your complete financial picture, in one place.',
              style: TextStyle(color: _muted, fontSize: 13)),
          const SizedBox(height: 20),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(19),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF48235F), Color(0xFF21152F)],
                begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(23),
              border: Border.all(color: _lavender.withOpacity(0.24)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('TOTAL NET WORTH',
                    style: TextStyle(color: _muted, fontSize: 10,
                        letterSpacing: 1.4, fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                const Text('₹8,45,250',
                    style: TextStyle(color: Colors.white, fontSize: 30,
                        fontWeight: FontWeight.w700)),
                const SizedBox(height: 5),
                const Text('↗ 4.8% this month',
                    style: TextStyle(color: Color(0xFF79DDB0), fontSize: 12)),
                const SizedBox(height: 18),
                Row(
                  children: const [
                    Expanded(child: _WealthMiniStat(
                        label: 'TOTAL ASSETS', value: '₹10,25,000')),
                    SizedBox(width: 12),
                    Expanded(child: _WealthMiniStat(
                        label: 'LIABILITIES', value: '₹1,79,750')),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 23),
          const Text('WEALTH GROWTH',
              style: TextStyle(color: _muted, fontSize: 10,
                  letterSpacing: 1.3, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.fromLTRB(15, 15, 15, 12),
            decoration: BoxDecoration(
              color: _panel.withOpacity(0.82),
              borderRadius: BorderRadius.circular(19),
              border: Border.all(color: Colors.white.withOpacity(0.06)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('₹8,45,250',
                    style: const TextStyle(color: Colors.white,
                        fontSize: 20, fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                const Text('Illustrative net worth trend',
                    style: TextStyle(color: _muted, fontSize: 10)),
                const SizedBox(height: 12),
                SizedBox(height: 95, child: _WealthLineChart(period: _period)),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: ['1M', '3M', '6M', '1Y'].map((period) {
                    final selected = _period == period;
                    return GestureDetector(
                      onTap: () => setState(() => _period = period),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 13, vertical: 7),
                        decoration: BoxDecoration(
                          color: selected
                              ? const Color(0xFF69418B)
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(period, style: TextStyle(
                          color: selected ? Colors.white : _muted,
                          fontSize: 10, fontWeight: FontWeight.w600)),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
          const SizedBox(height: 23),
          const Text('WHERE YOUR MONEY IS',
              style: TextStyle(color: _muted, fontSize: 10,
                  letterSpacing: 1.3, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          const _WealthBreakdownRow(
            icon: Icons.account_balance_outlined,
            title: 'Bank balance', subtitle: 'Savings and current accounts',
            amount: '₹2,50,000', percent: '24%', fraction: 0.24,
            tint: Color(0xFFB98BFF)),
          const _WealthBreakdownRow(
            icon: Icons.trending_up_rounded,
            title: 'Investments', subtitle: 'Stocks and mutual funds',
            amount: '₹3,72,800', percent: '36%', fraction: 0.36,
            tint: Color(0xFF65C9D3)),
          const _WealthBreakdownRow(
            icon: Icons.lock_outline_rounded,
            title: 'Fixed deposits', subtitle: 'Long-term deposits',
            amount: '₹2,80,000', percent: '27%', fraction: 0.27,
            tint: Color(0xFFDBA0FF)),
          const _WealthBreakdownRow(
            icon: Icons.savings_outlined,
            title: 'Other assets', subtitle: 'Additional holdings',
            amount: '₹1,22,200', percent: '13%', fraction: 0.13,
            tint: Color(0xFF7ADDAA)),
          const SizedBox(height: 20),
          const Text('LIABILITIES',
              style: TextStyle(color: _muted, fontSize: 10,
                  letterSpacing: 1.3, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          const _WealthBreakdownRow(
            icon: Icons.credit_card_rounded,
            title: 'Outstanding dues', subtitle: 'Loans and credit balances',
            amount: '₹1,79,750', percent: '100%', fraction: 1,
            tint: Color(0xFFE59BBD), compact: true),
          const SizedBox(height: 15),
          const Text('ASK INVESTMATE',
              style: TextStyle(color: _muted, fontSize: 10,
                  letterSpacing: 1.3, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            _WealthPromptChip(label: 'Explain my assets',
              onTap: () => widget.onPrompt('Explain my assets')),
            _WealthPromptChip(label: 'How has my wealth grown?',
              onTap: () => widget.onPrompt('How has my wealth grown?')),
            _WealthPromptChip(label: 'Review my liabilities',
              onTap: () => widget.onPrompt('Review my liabilities')),
          ]),
          const SizedBox(height: 12),
          const Text('All figures are illustrative mock data.',
              style: TextStyle(color: _muted, fontSize: 9)),
        ],
      ),
    );
  }
}

class _WealthMiniStat extends StatelessWidget {
  const _WealthMiniStat({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(11),
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(0.06),
      borderRadius: BorderRadius.circular(13)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(color: _muted, fontSize: 8,
          letterSpacing: 0.8)),
      const SizedBox(height: 5),
      FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft,
        child: Text(value, style: const TextStyle(color: Colors.white,
            fontSize: 15, fontWeight: FontWeight.w700))),
    ]),
  );
}

class _WealthBreakdownRow extends StatelessWidget {
  const _WealthBreakdownRow({
    required this.icon, required this.title, required this.subtitle,
    required this.amount, required this.percent, required this.fraction,
    required this.tint, this.compact = false,
  });
  final IconData icon;
  final String title, subtitle, amount, percent;
  final double fraction;
  final Color tint;
  final bool compact;

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 9),
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: _panel.withOpacity(0.78),
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: Colors.white.withOpacity(0.055))),
    child: Row(children: [
      SizedBox(width: 54, height: 54, child: Stack(alignment: Alignment.center,
        children: [
          SizedBox.expand(child: CircularProgressIndicator(
            value: fraction, strokeWidth: 5,
            backgroundColor: Colors.white.withOpacity(0.08),
            valueColor: AlwaysStoppedAnimation<Color>(tint))),
          Icon(icon, color: tint, size: 20),
        ])),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: Colors.white,
              fontSize: 12, fontWeight: FontWeight.w600)),
          const SizedBox(height: 3),
          Text(subtitle, style: const TextStyle(color: _muted, fontSize: 9)),
        ])),
      const SizedBox(width: 6),
      Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Text(amount, style: const TextStyle(color: Colors.white,
            fontSize: 13, fontWeight: FontWeight.w700)),
        const SizedBox(height: 3),
        Text(percent, style: TextStyle(color: tint, fontSize: 10,
            fontWeight: FontWeight.w600)),
      ]),
    ]),
  );
}

class _WealthLineChart extends StatelessWidget {
  const _WealthLineChart({required this.period});
  final String period;

  @override
  Widget build(BuildContext context) => CustomPaint(
    painter: _WealthChartPainter(period),
    child: const SizedBox.expand(),
  );
}

class _WealthChartPainter extends CustomPainter {
  _WealthChartPainter(this.period);
  final String period;

  @override
  void paint(Canvas canvas, Size size) {
    final values = period == '1M'
        ? [0.72, 0.67, 0.76, 0.70, 0.81, 0.75, 0.88, 0.84]
        : period == '3M'
            ? [0.48, 0.57, 0.52, 0.65, 0.61, 0.75, 0.71, 0.88]
            : period == '1Y'
                ? [0.25, 0.32, 0.29, 0.44, 0.50, 0.59, 0.72, 0.88]
                : [0.40, 0.48, 0.43, 0.61, 0.56, 0.69, 0.76, 0.88];
    final path = Path();
    for (var i = 0; i < values.length; i++) {
      final point = Offset(
        size.width * i / (values.length - 1),
        size.height * (1 - values[i]),
      );
      if (i == 0) {
        path.moveTo(point.dx, point.dy);
      } else {
        final previous = Offset(
          size.width * (i - 1) / (values.length - 1),
          size.height * (1 - values[i - 1]),
        );
        final mid = (previous.dx + point.dx) / 2;
        path.cubicTo(mid, previous.dy, mid, point.dy, point.dx, point.dy);
      }
    }
    final line = Paint()
      ..color = const Color(0xFFC18BFF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(path, line);
    final fill = Path.from(path)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    final fillPaint = Paint()
      ..shader = const LinearGradient(
        colors: [Color(0x66B77AFF), Color(0x00100A1B)],
        begin: Alignment.topCenter, end: Alignment.bottomCenter,
      ).createShader(Offset.zero & size);
    canvas.drawPath(fill, fillPaint);
  }

  @override
  bool shouldRepaint(covariant _WealthChartPainter oldDelegate) =>
      oldDelegate.period != period;
}

class _WealthPromptChip extends StatelessWidget {
  const _WealthPromptChip({required this.label, required this.onTap});
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => ActionChip(
    onPressed: onTap,
    backgroundColor: const Color(0xFF30203F),
    side: BorderSide(color: _lavender.withOpacity(0.2)),
    label: Text(label, style: const TextStyle(color: Colors.white, fontSize: 10)),
  );
}

class _MiniBars extends StatelessWidget {
  const _MiniBars({required this.seed});
  final int seed;

  @override
  Widget build(BuildContext context) {
    final heights = seed == 1
        ? [25.0, 36.0, 30.0, 48.0, 42.0, 57.0, 68.0, 61.0]
        : seed == 2
            ? [28.0, 34.0, 26.0, 45.0, 39.0, 58.0, 51.0, 72.0]
            : [42.0, 47.0, 39.0, 52.0, 45.0, 61.0, 56.0, 66.0];
    return SizedBox(
      height: 76,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: heights.map((height) {
          return Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Container(
                height: height,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  gradient: const LinearGradient(
                    colors: [Color(0xFFDB9AFF), Color(0xFF7041A4)],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
