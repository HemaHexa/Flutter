import 'dart:math' as math;
import 'package:flutter/material.dart';

const Color _background = Color(0xFF10091B);
const Color _panel = Color(0xFF21152F);
const Color _muted = Color(0xFFB9A7CB);
const Color _lavender = Color(0xFFC18BFF);

part 'home_screen.dart';
part 'credit_health_screen.dart';
part 'investment_screen.dart';
part 'wealth_screen.dart';
part 'shared_widgets.dart';
part 'ai_conversation_screen.dart';
