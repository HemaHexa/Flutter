part of 'home_screen.dart';

class _CreditHealthScreen extends StatelessWidget {
  const _CreditHealthScreen({required this.onPrompt});
  final ValueChanged<String> onPrompt;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(24, 28, 38, 28),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('04  /  04  ·  YOUR CREDIT PROFILE', style: TextStyle(color: _muted, fontSize: 9, letterSpacing: 1.3, fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        const Text('Credit health', style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w700)),
        const SizedBox(height: 7),
        const Text('A clearer view of the habits behind your score.', style: TextStyle(color: _muted)),
        const SizedBox(height: 26),
        Container(width: double.infinity, padding: const EdgeInsets.all(22), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF38204F), Color(0xFF21152F)], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(24), border: Border.all(color: _lavender.withOpacity(.22))),
          child: Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: const [Text('YOUR DEMO CREDIT SCORE', style: TextStyle(color: _muted, fontSize: 10, letterSpacing: 1.4)), Icon(Icons.shield_outlined, color: Color(0xFFB98AFF))]),
            const SizedBox(height: 18),
            SizedBox(height: 142, width: 190, child: CustomPaint(painter: _CreditGaugePainter(), child: Column(mainAxisAlignment: MainAxisAlignment.end, children: const [Text('782', style: TextStyle(color: Colors.white, fontSize: 42, fontWeight: FontWeight.w700)), SizedBox(height: 3), Text('VERY GOOD', style: TextStyle(color: Color(0xFF79DDB0), fontSize: 10, letterSpacing: 2, fontWeight: FontWeight.w700)), SizedBox(height: 8)]))),
            const SizedBox(height: 14),
            const Text('Illustrative score · Updated today', style: TextStyle(color: _muted, fontSize: 11)),
            const SizedBox(height: 18),
            Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.white.withOpacity(.055), borderRadius: BorderRadius.circular(14)), child: const Row(children: [Icon(Icons.trending_up_rounded, color: Color(0xFF79DDB0), size: 18), SizedBox(width: 9), Expanded(child: Text('You’re in a healthy range. Keep building consistent credit habits.', style: TextStyle(color: Colors.white, fontSize: 11, height: 1.4)))])),
          ])),
        const SizedBox(height: 22),
        const Text('WHAT SHAPES YOUR SCORE', style: TextStyle(color: Color(0xFFD7B9F4), fontSize: 11, letterSpacing: 1.4, fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        _CreditFactor(icon: Icons.credit_card_rounded, title: 'Credit utilisation', value: '18%', detail: 'Low usage · Sample limit ₹2,00,000', progress: .18, color: const Color(0xFF79DDB0)),
        _CreditFactor(icon: Icons.event_available_rounded, title: 'Payment history', value: '98%', detail: 'On-time payments in this demo', progress: .98, color: const Color(0xFF79DDB0)),
        _CreditFactor(icon: Icons.history_rounded, title: 'Credit age', value: '4.2 yrs', detail: 'Illustrative average account age', progress: .56, color: const Color(0xFF9D8BFF)),
        _CreditFactor(icon: Icons.search_rounded, title: 'Recent enquiries', value: '1', detail: 'Sample enquiry in the last 6 months', progress: .25, color: const Color(0xFFFFC078)),
        const SizedBox(height: 20),
        const Text('ASK YOUR AI ADVISOR', style: TextStyle(color: Color(0xFFD7B9F4), fontSize: 11, letterSpacing: 1.4, fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        Wrap(spacing: 9, runSpacing: 9, children: [
          _WealthPromptChip(label: 'Explain my credit score', onTap: () => onPrompt('Explain my credit score')),
          _WealthPromptChip(label: 'How can I improve it?', onTap: () => onPrompt('How can I improve my credit score?')),
          _WealthPromptChip(label: 'What is utilisation?', onTap: () => onPrompt('Explain credit utilisation')),
          _WealthPromptChip(label: 'Why do payments matter?', onTap: () => onPrompt('Why do timely payments matter?')),
        ]),
        const SizedBox(height: 16),
        const Text('All figures are fictional demo data. InvestMate is not connected to a credit bureau and this is not a credit report.', style: TextStyle(color: _muted, fontSize: 10, height: 1.5)),
      ]),
    );
  }
}

class _CreditFactor extends StatelessWidget {
  const _CreditFactor({required this.icon, required this.title, required this.value, required this.detail, required this.progress, required this.color});
  final IconData icon; final String title; final String value; final String detail; final double progress; final Color color;
  @override
  Widget build(BuildContext context) => Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: _panel.withOpacity(.82), borderRadius: BorderRadius.circular(17), border: Border.all(color: Colors.white.withOpacity(.055))), child: Column(children: [Row(children: [Icon(icon, color: _lavender, size: 19), const SizedBox(width: 10), Expanded(child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600))), Text(value, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700))]), const SizedBox(height: 9), ClipRRect(borderRadius: BorderRadius.circular(8), child: LinearProgressIndicator(value: progress, minHeight: 5, backgroundColor: Colors.white.withOpacity(.08), valueColor: AlwaysStoppedAnimation<Color>(color))), const SizedBox(height: 7), Align(alignment: Alignment.centerLeft, child: Text(detail, style: const TextStyle(color: _muted, fontSize: 10)))]));
}

class _CreditGaugePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(12, 8, size.width - 24, size.height * 1.65);
    final base = Paint()..color = Colors.white.withOpacity(.10)..style = PaintingStyle.stroke..strokeWidth = 12..strokeCap = StrokeCap.round;
    final value = Paint()..shader = const SweepGradient(startAngle: math.pi, endAngle: math.pi * 2, colors: [Color(0xFF8D65E8), Color(0xFF79DDB0)]).createShader(rect)..style = PaintingStyle.stroke..strokeWidth = 12..strokeCap = StrokeCap.round;
    canvas.drawArc(rect, math.pi, math.pi, false, base);
    canvas.drawArc(rect, math.pi, math.pi * .782, false, value);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
