part of 'home_screen.dart';

class _BottomDock extends StatelessWidget {
  const _BottomDock({
    required this.isRecording,
    required this.onPlus,
    required this.onTap,
    required this.onLongPressStart,
    required this.onLongPressEnd,
  });

  final bool isRecording;
  final VoidCallback onPlus;
  final VoidCallback onTap;
  final VoidCallback onLongPressStart;
  final VoidCallback onLongPressEnd;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(17, 8, 17, 0),
      child: Row(
        children: [
          Material(
            color: const Color(0xFF281A38),
            shape: const CircleBorder(),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: onPlus,
              child: const SizedBox(
                width: 48,
                height: 48,
                child: Icon(Icons.add_rounded, color: Color(0xFFD7B5F5)),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: GestureDetector(
              onTap: onTap,
              onLongPressStart: (_) => onLongPressStart(),
              onLongPressEnd: (_) => onLongPressEnd(),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                height: 52,
                decoration: BoxDecoration(
                  color: isRecording
                      ? const Color(0xFF55306F)
                      : const Color(0xFF281A38),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(
                    color: isRecording ? _lavender : Colors.white12,
                    width: isRecording ? 1.4 : 0.8,
                  ),
                  boxShadow: isRecording
                      ? [
                          BoxShadow(
                            color: _lavender.withOpacity(0.25),
                            blurRadius: 18,
                            spreadRadius: 1,
                          )
                        ]
                      : null,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      isRecording ? Icons.graphic_eq : Icons.edit_outlined,
                      color: const Color(0xFFD9B8F6),
                      size: 17,
                    ),
                    const SizedBox(width: 9),
                    Text(
                      isRecording
                          ? 'Listening… release to finish'
                          : 'Tap to type · Hold to speak',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionIndicators extends StatelessWidget {
  const _SectionIndicators({
    required this.activeIndex,
    required this.onSelect,
  });

  final int activeIndex;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(4, (index) {
        final active = activeIndex == index;
        return GestureDetector(
          onTap: () => onSelect(index),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            margin: const EdgeInsets.symmetric(vertical: 7),
            width: 7,
            height: active ? 25 : 7,
            decoration: BoxDecoration(
              color: active ? _lavender : const Color(0xFF665174),
              borderRadius: BorderRadius.circular(20),
              boxShadow: active
                  ? [
                      BoxShadow(
                        color: _lavender.withOpacity(0.65),
                        blurRadius: 12,
                      )
                    ]
                  : null,
            ),
          ),
        );
      }),
    );
  }
}

class _SuggestionChip extends StatelessWidget {
  const _SuggestionChip({
    required this.label,
    required this.icon,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ActionChip(
        onPressed: onTap,
        avatar: Icon(icon, size: 16, color: const Color(0xFFD6B5F4)),
        label: Text(label),
        backgroundColor: const Color(0xFF281A38),
        side: BorderSide(color: Colors.white.withOpacity(0.08)),
        labelStyle: const TextStyle(color: Colors.white, fontSize: 11),
        shape: const StadiumBorder(),
      ),
    );
  }
}

class _MessageComposer extends StatefulWidget {
  const _MessageComposer({required this.onSend});
  final ValueChanged<String> onSend;

  @override
  State<_MessageComposer> createState() => _MessageComposerState();
}

class _MessageComposerState extends State<_MessageComposer> {
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.fromLTRB(
          20,
          20,
          20,
          18 + MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'What would you like to know?',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _controller,
              autofocus: true,
              minLines: 1,
              maxLines: 4,
              textInputAction: TextInputAction.send,
              onSubmitted: (value) {
                if (value.trim().isNotEmpty) widget.onSend(value.trim());
              },
              decoration: InputDecoration(
                hintText: 'Ask InvestMate anything…',
                filled: true,
                fillColor: const Color(0xFF352342),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide.none,
                ),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.arrow_upward_rounded),
                  onPressed: () {
                    final value = _controller.text.trim();
                    if (value.isNotEmpty) widget.onSend(value);
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionRow extends StatelessWidget {
  const _ActionRow({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: CircleAvatar(
        backgroundColor: const Color(0xFF39264C),
        child: Icon(icon, color: _lavender),
      ),
      title: Text(title),
      subtitle: Text(subtitle, style: const TextStyle(color: _muted)),
      onTap: onTap,
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: _panel.withOpacity(0.75),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Row(
        children: [
          Icon(icon, color: _lavender, size: 22),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        color: Colors.white, fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                Text(subtitle,
                    style: const TextStyle(color: _muted, fontSize: 11)),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded, color: _muted),
        ],
      ),
    );
  }
}

class _SectionData {
  const _SectionData({
    required this.title,
    required this.eyebrow,
    required this.subtitle,
  });

  final String title;
  final String eyebrow;
  final String subtitle;
}

class _AmbientBackground extends StatelessWidget {
  const _AmbientBackground();

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: IgnorePointer(
        child: Stack(
          children: [
            Positioned(
              top: -130,
              left: -110,
              child: _GlowBlob(
                size: 290,
                color: const Color(0xFF59257E).withOpacity(0.28),
              ),
            ),
            Positioned(
              top: 250,
              right: -170,
              child: _GlowBlob(
                size: 310,
                color: const Color(0xFF302D78).withOpacity(0.17),
              ),
            ),
            Positioned(
              bottom: -180,
              left: 30,
              child: _GlowBlob(
                size: 300,
                color: const Color(0xFF6A287D).withOpacity(0.15),
              ),
            ),
            Positioned(
              bottom: 90,
              right: -210,
              child: _GlowBlob(
                size: 270,
                color: const Color(0xFF2CAFA5).withOpacity(0.075),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GlowBlob extends StatelessWidget {
  const _GlowBlob({required this.size, required this.color});
  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(color: color, blurRadius: 100, spreadRadius: 35),
        ],
      ),
    );
  }
}

class _OrbPainter extends CustomPainter {
  _OrbPainter(this.progress);
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width * 0.34;
    final rotation = progress * math.pi * 2;

    final outer = Paint()
      ..shader = RadialGradient(
        colors: [
          const Color(0xFFB97BEE).withOpacity(0.05),
          const Color(0xFF9C54D5).withOpacity(0.24),
          const Color(0xFF572A82).withOpacity(0.02),
          Colors.transparent,
        ],
        stops: const [0, 0.48, 0.78, 1],
      ).createShader(Rect.fromCircle(center: center, radius: size.width * 0.49));
    canvas.drawCircle(center, size.width * 0.49, outer);

    final core = Paint()
      ..shader = const RadialGradient(
        center: Alignment(-0.35, -0.45),
        colors: [
          Color(0xFFE4B8FF),
          Color(0xFFB56DE9),
          Color(0xFF783CB1),
          Color(0xFF351A58),
        ],
        stops: [0, 0.28, 0.68, 1],
      ).createShader(Rect.fromCircle(center: center, radius: radius));
    canvas.drawCircle(center, radius, core);

    final ringPaint = Paint()
      ..color = const Color(0xFFDDB7FF).withOpacity(0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;
    canvas.drawCircle(center, radius + 13, ringPaint);

    final orbitPaint = Paint()
      ..color = const Color(0xFFEDCFFF).withOpacity(0.8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius + 21),
      rotation,
      math.pi * 0.75,
      false,
      orbitPaint,
    );

    final dotAngle = rotation * 1.7;
    final dot = Offset(
      center.dx + math.cos(dotAngle) * (radius + 21),
      center.dy + math.sin(dotAngle) * (radius + 21),
    );
    canvas.drawCircle(
      dot,
      4,
      Paint()..color = const Color(0xFFF0D9FF),
    );
  }

  @override
  bool shouldRepaint(covariant _OrbPainter oldDelegate) =>
      oldDelegate.progress != progress;
}


// Conversational response prototype. All figures and responses are mock data.
