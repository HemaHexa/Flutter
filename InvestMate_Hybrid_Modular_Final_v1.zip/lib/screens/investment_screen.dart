part of 'home_screen.dart';

class _InvestmentDetailScreen extends StatefulWidget {
  const _InvestmentDetailScreen({required this.onPrompt});
  final ValueChanged<String> onPrompt;

  @override
  State<_InvestmentDetailScreen> createState() => _InvestmentDetailScreenState();
}

class _InvestmentDetailScreenState extends State<_InvestmentDetailScreen> {
  String _period = '1M';
  static const _holdings = <_HoldingData>[
    _HoldingData('Nifty 50 Index Fund', 'Mutual fund · Equity', '₹1,45,000', '+12.4%', Icons.show_chart_rounded, Color(0xFFB98BFF)),
    _HoldingData('HDFC Bank', 'Stock · Banking', '₹82,500', '+6.8%', Icons.account_balance_rounded, Color(0xFF73C9D4)),
    _HoldingData('Reliance Industries', 'Stock · Energy & retail', '₹95,300', '+9.1%', Icons.bolt_rounded, Color(0xFFDBA0FF)),
    _HoldingData('Gold ETF', 'ETF · Commodity', '₹50,000', '+3.2%', Icons.diamond_outlined, Color(0xFFE6C47B)),
  ];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(23, 24, 38, 28),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('02 / 03  ·  BUILDING YOUR PORTFOLIO',
          style: TextStyle(color: _muted, fontSize: 9, letterSpacing: 1.2, fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        const Text('My Investments', style: TextStyle(color: Colors.white, fontSize: 31, fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        const Text('Your holdings, performance and next moves.', style: TextStyle(color: _muted, fontSize: 12)),
        const SizedBox(height: 19),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF4B2866), Color(0xFF21152F)], begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.circular(23),
            border: Border.all(color: _lavender.withOpacity(.24)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('CURRENT PORTFOLIO VALUE', style: TextStyle(color: _muted, fontSize: 9, letterSpacing: 1.3, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            const Text('₹3,72,800', style: TextStyle(color: Colors.white, fontSize: 29, fontWeight: FontWeight.w700)),
            const SizedBox(height: 5),
            const Row(children: [
              Icon(Icons.trending_up_rounded, color: Color(0xFF79DDB0), size: 16),
              SizedBox(width: 4),
              Text('+₹29,500  ·  +8.6% overall', style: TextStyle(color: Color(0xFF79DDB0), fontSize: 11, fontWeight: FontWeight.w600)),
            ]),
            const SizedBox(height: 17),
            Row(children: [
              const Expanded(child: _WealthMiniStat(label: 'INVESTED', value: '₹3,43,300')),
              const SizedBox(width: 10),
              const Expanded(child: _WealthMiniStat(label: 'TOTAL RETURNS', value: '+₹29,500')),
            ]),
            const SizedBox(height: 17),
            Row(children: [
              Expanded(child: _InvestmentActionButton(label: 'Buy', icon: Icons.add_rounded, onTap: () => _openTrade('Buy'))),
              const SizedBox(width: 10),
              Expanded(child: _InvestmentActionButton(label: 'Sell', icon: Icons.remove_rounded, onTap: () => _openTrade('Sell'), secondary: true)),
            ]),
          ]),
        ),
        const SizedBox(height: 21),
        const Text('PORTFOLIO PERFORMANCE', style: TextStyle(color: _muted, fontSize: 10, letterSpacing: 1.3, fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(color: _panel.withOpacity(.84), borderRadius: BorderRadius.circular(19), border: Border.all(color: Colors.white.withOpacity(.06))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('+8.6%', style: TextStyle(color: Color(0xFF79DDB0), fontSize: 23, fontWeight: FontWeight.w700)),
            const SizedBox(height: 3),
            const Text('Illustrative portfolio return', style: TextStyle(color: _muted, fontSize: 10)),
            const SizedBox(height: 12),
            SizedBox(height: 82, child: _MiniBars(seed: _period == '1D' ? 1 : _period == '1Y' ? 3 : 2)),
            const SizedBox(height: 9),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: ['1D', '1M', '3M', '6M', '1Y'].map((p) {
              final selected = _period == p;
              return GestureDetector(onTap: () => setState(() => _period = p), child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(color: selected ? const Color(0xFF69418B) : Colors.transparent, borderRadius: BorderRadius.circular(18)),
                child: Text(p, style: TextStyle(color: selected ? Colors.white : _muted, fontSize: 10, fontWeight: FontWeight.w600)),
              ));
            }).toList()),
          ]),
        ),
        const SizedBox(height: 21),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('MY HOLDINGS', style: TextStyle(color: _muted, fontSize: 10, letterSpacing: 1.3, fontWeight: FontWeight.w700)),
          Text('${_holdings.length} ASSETS', style: const TextStyle(color: _muted, fontSize: 9)),
        ]),
        const SizedBox(height: 10),
        ..._holdings.map((holding) => _HoldingCard(
          holding: holding,
          onTap: () => _showHoldingDetail(holding),
        )),
        const SizedBox(height: 13),
        const Text('ASK INVESTMATE', style: TextStyle(color: _muted, fontSize: 10, letterSpacing: 1.3, fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          _WealthPromptChip(label: 'Explain my portfolio', onTap: () => widget.onPrompt('Explain my investment portfolio')),
          _WealthPromptChip(label: 'Which holding performs best?', onTap: () => widget.onPrompt('Which holding performs best?')),
          _WealthPromptChip(label: 'How diversified am I?', onTap: () => widget.onPrompt('Explain my investment allocation and diversification')),
          _WealthPromptChip(label: 'Why can my portfolio go down?', onTap: () => widget.onPrompt('Why can my portfolio go down?')),
        ]),
        const SizedBox(height: 12),
        const Text('All holdings, prices and returns are illustrative demo data. Buy and sell actions do not place real orders.', style: TextStyle(color: _muted, fontSize: 9)),
      ]),
    );
  }

  void _showHoldingDetail(_HoldingData h) {
    showModalBottomSheet<void>(context: context, backgroundColor: _panel, shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(25))), builder: (ctx) => SafeArea(child: Padding(
      padding: const EdgeInsets.fromLTRB(22, 22, 22, 28),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [CircleAvatar(backgroundColor: h.tint.withOpacity(.15), child: Icon(h.icon, color: h.tint)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(h.name, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700)), Text(h.type, style: const TextStyle(color: _muted, fontSize: 11))]))]),
        const SizedBox(height: 22),
        const Text('CURRENT VALUE', style: TextStyle(color: _muted, fontSize: 9, letterSpacing: 1.2)),
        const SizedBox(height: 5),
        Text(h.value, style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w700)),
        const SizedBox(height: 5),
        Text('${h.returnPct} illustrative return', style: const TextStyle(color: Color(0xFF79DDB0), fontSize: 12)),
        const SizedBox(height: 17),
        const Text('This holding is part of your sample InvestMate portfolio. No live market feed or brokerage account is connected.', style: TextStyle(color: _muted, fontSize: 11, height: 1.5)),
      ]),
    )));
  }

  void _openTrade(String side) {
    showModalBottomSheet<void>(
      context: context, isScrollControlled: true, backgroundColor: _panel,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
      builder: (ctx) => _TradeSheet(side: side),
    );
  }
}

class _HoldingData {
  const _HoldingData(this.name, this.type, this.value, this.returnPct, this.icon, this.tint);
  final String name, type, value, returnPct;
  final IconData icon;
  final Color tint;
}

class _HoldingCard extends StatelessWidget {
  const _HoldingCard({required this.holding, required this.onTap});
  final _HoldingData holding;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap, borderRadius: BorderRadius.circular(16),
    child: Container(
      margin: const EdgeInsets.only(bottom: 9), padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: _panel.withOpacity(.8), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white.withOpacity(.055))),
      child: Row(children: [
        SizedBox(width: 46, height: 46, child: Stack(alignment: Alignment.center, children: [
          CircularProgressIndicator(value: .72, strokeWidth: 4, backgroundColor: Colors.white.withOpacity(.07), valueColor: AlwaysStoppedAnimation<Color>(holding.tint)),
          Icon(holding.icon, color: holding.tint, size: 19),
        ])),
        const SizedBox(width: 11),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(holding.name, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
          const SizedBox(height: 3),
          Text(holding.type, style: const TextStyle(color: _muted, fontSize: 9)),
        ])),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(holding.value, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
          const SizedBox(height: 3),
          Text(holding.returnPct, style: const TextStyle(color: Color(0xFF79DDB0), fontSize: 10, fontWeight: FontWeight.w600)),
        ]),
        const SizedBox(width: 4), const Icon(Icons.chevron_right_rounded, color: _muted, size: 17),
      ]),
    ),
  );
}

class _InvestmentActionButton extends StatelessWidget {
  const _InvestmentActionButton({required this.label, required this.icon, required this.onTap, this.secondary = false});
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  final bool secondary;
  @override
  Widget build(BuildContext context) => Material(
    color: secondary ? Colors.white.withOpacity(.07) : const Color(0xFFB98BFF),
    borderRadius: BorderRadius.circular(14),
    child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(14), child: Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, color: secondary ? Colors.white : const Color(0xFF24132F), size: 17),
        const SizedBox(width: 6),
        Text(label, style: TextStyle(color: secondary ? Colors.white : const Color(0xFF24132F), fontWeight: FontWeight.w700, fontSize: 12)),
      ]),
    )),
  );
}

class _TradeSheet extends StatefulWidget {
  const _TradeSheet({required this.side});
  final String side;
  @override
  State<_TradeSheet> createState() => _TradeSheetState();
}

class _TradeSheetState extends State<_TradeSheet> {
  double _amount = 5000;
  final double _maximum = 50000;
  final ScrollController _rulerController = ScrollController();

  @override
  void dispose() { _rulerController.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final isBuy = widget.side == 'Buy';
    return SafeArea(child: Padding(
      padding: EdgeInsets.fromLTRB(20, 22, 20, 22 + MediaQuery.of(context).viewInsets.bottom),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: Text('${widget.side} investment', style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w700))), IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close, color: _muted))]),
        Text(isBuy ? 'Choose an amount to invest' : 'Choose an amount to redeem', style: const TextStyle(color: _muted, fontSize: 12)),
        const SizedBox(height: 18),
        Center(child: Column(children: [
          Text('₹${_amount.round().toString().replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}', style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w700)),
          const SizedBox(height: 3), Text('Maximum demo amount ₹50,000', style: const TextStyle(color: _muted, fontSize: 10)),
        ])),
        const SizedBox(height: 18),
        SizedBox(height: 76, child: LayoutBuilder(builder: (context, constraints) {
          return GestureDetector(
            onHorizontalDragUpdate: (details) {
              setState(() => _amount = (_amount + details.delta.dx * 180).clamp(0, _maximum));
            },
            child: CustomPaint(
              size: Size(constraints.maxWidth, 76),
              painter: _RulerPainter(value: _amount, maximum: _maximum),
              child: const SizedBox.expand(),
            ),
          );
        })),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: const [Text('₹0', style: TextStyle(color: _muted, fontSize: 9)), Text('Drag ruler to adjust', style: TextStyle(color: _muted, fontSize: 9)), Text('₹50k', style: TextStyle(color: _muted, fontSize: 9))]),
        const SizedBox(height: 20),
        SizedBox(width: double.infinity, child: ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: _lavender, foregroundColor: _background, padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          onPressed: _amount <= 0 ? null : () => _confirmTrade(context),
          child: Text('Review ${widget.side.toLowerCase()}'),
        )),
        const SizedBox(height: 7),
        const Text('Demo only — no order will be placed or money moved.', style: TextStyle(color: _muted, fontSize: 9)),
      ]),
    ));
  }

  void _confirmTrade(BuildContext context) {
    showDialog<void>(context: context, builder: (dialogContext) => AlertDialog(
      backgroundColor: const Color(0xFF30203F),
      title: Text('Confirm demo ${widget.side.toLowerCase()}?', style: const TextStyle(color: Colors.white)),
      content: Text('You selected ₹${_amount.round()} for a simulated ${widget.side.toLowerCase()} action. This will not connect to a broker or execute a real order.', style: const TextStyle(color: _muted, height: 1.45)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Go back')),
        ElevatedButton(onPressed: () {
          Navigator.pop(dialogContext);
          Navigator.pop(context);
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Demo order reviewed — no real transaction was made.'), behavior: SnackBarBehavior.floating));
        }, child: const Text('Confirm demo')),
      ],
    ));
  }
}

class _RulerPainter extends CustomPainter {
  _RulerPainter({required this.value, required this.maximum});
  final double value, maximum;
  @override
  void paint(Canvas canvas, Size size) {
    final centerY = size.height * .57;
    final base = Paint()..color = Colors.white.withOpacity(.22)..strokeWidth = 1;
    final active = Paint()..color = _lavender..strokeWidth = 2;
    final centerX = size.width * (value / maximum);
    for (double x = 0; x <= size.width; x += 8) {
      final tick = ((x / size.width) * 50).round();
      final major = tick % 5 == 0;
      final y = centerY - (major ? 22 : 11);
      canvas.drawLine(Offset(x, y), Offset(x, centerY + (major ? 15 : 7)), x <= centerX ? active : base);
    }
    final marker = Paint()..color = const Color(0xFFE8D5FF)..strokeWidth = 2.4;
    canvas.drawLine(Offset(centerX, 3), Offset(centerX, size.height - 2), marker);
  }
  @override
  bool shouldRepaint(covariant _RulerPainter old) => old.value != value;
}
