part of 'home_screen.dart';

class _ConversationScreen extends StatefulWidget {
  const _ConversationScreen({required this.initialPrompt});
  final String initialPrompt;

  @override
  State<_ConversationScreen> createState() => _ConversationScreenState();
}

class _ConversationScreenState extends State<_ConversationScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _thinkingController;
  bool _thinking = true;
  final List<_ChatMessage> _messages = [];
  final TextEditingController _inputController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _thinkingController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..repeat(reverse: true);
    _messages.add(_ChatMessage(widget.initialPrompt, true));
    _generateMockAnswer(widget.initialPrompt);
  }

  Future<void> _generateMockAnswer(String prompt) async {
    await Future.delayed(const Duration(milliseconds: 1700));
    if (!mounted) return;
    setState(() {
      _thinking = false;
      _messages.add(_ChatMessage(_answerFor(prompt), false));
    });
  }

  String _answerFor(String prompt) {
    final q = prompt.toLowerCase();
    if (q.contains('overall') || q.contains('together') || q.contains('financial picture') || q.contains('connect') || q.contains('full picture')) {
      return 'Let’s connect your demo finances. Your illustrative net worth is ₹8,45,250 (₹10,25,000 assets minus ₹1,79,750 liabilities). Your investment portfolio is ₹3,72,800 with a sample return of +8.6%. Your demo credit score is 782, with 18% utilisation and 98% on-time payments. A useful next step is to keep an emergency cash buffer, review high-interest liabilities, and make investment choices that fit your time horizon. All figures are fictional demo data, not live account information or personalised regulated financial advice.';
    }
    if (q.contains('asset')) {
      return 'Here is how your illustrative assets are distributed: bank balance ₹2,50,000 (24%), investments ₹3,72,800 (36%), fixed deposits ₹2,80,000 (27%), and other assets ₹1,22,200 (13%). Together, these add up to ₹10,25,000 in total assets. These are sample values only.';
    }
    if (q.contains('grown') || q.contains('growth') || q.contains('wealth')) {
      return 'Your illustrative net worth is ₹8,45,250, showing a sample increase of 4.8% this month. Net worth is calculated as total assets of ₹10,25,000 minus liabilities of ₹1,79,750. The chart periods let you explore a mock 1-month, 3-month, 6-month, or 1-year trend. These figures are demo data, not connected account information.';
    }
    if (q.contains('liabilit') || q.contains('debt') || q.contains('due')) {
      return 'Your sample liabilities total ₹1,79,750. They represent outstanding loans and credit balances in this demo. Comparing liabilities with your ₹10,25,000 in sample assets gives an illustrative net worth of ₹8,45,250. In a real account, we would break this down by loan, interest rate, and repayment date.';
    }
    if (q.contains('utilisation') || q.contains('utilization')) {
      return 'Credit utilisation is the share of your available revolving credit that you are using. In this demo it is 18% (sample balance ₹36,000 against a ₹2,00,000 limit). Lower utilisation is generally healthier; paying balances down and avoiding maxing out cards can help. These are fictional figures.';
    }
    if (q.contains('improve') || q.contains('payment') || q.contains('timely')) {
      return 'To build a stronger credit profile, pay every bill on time, keep credit utilisation modest, avoid applying for many new accounts at once, and review your credit report for errors. Your demo profile shows 98% on-time payments and 18% utilisation. These are illustrative values, not a real bureau assessment.';
    }
    if (q.contains('credit') || q.contains('score')) {
      return 'Your demo credit profile shows a score of 782, labelled Very Good. The sample factors are 18% utilisation, 98% on-time payments, 4.2 years average credit age and one recent enquiry. Real scoring models differ, and these figures are not connected to a credit bureau.';
    }
    if (q.contains('best') || q.contains('perform')) {
      return 'In this illustrative portfolio, the Nifty 50 Index Fund is showing the strongest sample return at +12.4%, followed by Reliance Industries at +9.1%. Past performance does not guarantee future results, and these demo figures are not market prices.';
    }
    if (q.contains('allocation') || q.contains('spread') || q.contains('holdings')) {
      return 'Your sample ₹3,72,800 portfolio is allocated across a Nifty 50 Index Fund (₹1,45,000), HDFC Bank (₹82,500), Reliance Industries (₹95,300), and Gold ETF (₹50,000). This is a mock portfolio designed for the InvestMate prototype.';
    }
    if (q.contains('risk') || q.contains('down') || q.contains('loss')) {
      return 'A portfolio can move up or down as market prices change. In this demo, the holdings include equity funds, individual stocks and gold, which have different risk drivers. Consider your time horizon, diversification and ability to tolerate losses before making real investment decisions.';
    }
    if (q.contains('investment') || q.contains('portfolio') || q.contains('stock')) {
      return 'Your demo investment portfolio is valued at ₹3,72,800, with an illustrative overall return of 8.6% (+₹29,500). It includes an index fund, two individual equity holdings and a gold ETF. These are sample values only, not live market prices or investment advice.';
    }
    return 'Here is your demo financial snapshot: estimated net worth ₹8,45,250, with sample wealth growth of 4.8% this month. Your next useful step is to review your investments and understand how each asset contributes to your overall wealth. These figures are mock data.';
  }

  void _sendFollowUp() {
    final text = _inputController.text.trim();
    if (text.isEmpty || _thinking) return;
    _inputController.clear();
    setState(() {
      _messages.add(_ChatMessage(text, true));
      _thinking = true;
    });
    _generateMockAnswer(text);
  }

  @override
  void dispose() {
    _thinkingController.dispose();
    _inputController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _background,
      appBar: AppBar(
        backgroundColor: _background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 19),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Row(
          children: [
            Icon(Icons.auto_awesome, color: _lavender, size: 20),
            SizedBox(width: 9),
            Text('InvestMate', style: TextStyle(fontWeight: FontWeight.w700)),
          ],
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 18),
            child: Center(
              child: Text('DEMO AI', style: TextStyle(color: _muted, fontSize: 10, letterSpacing: 1.2)),
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          const _AmbientBackground(),
          Column(
            children: [
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 20),
                  itemCount: _messages.length + (_thinking ? 1 : 0),
                  itemBuilder: (context, index) {
                    if (index == _messages.length) return _ThinkingIndicator(controller: _thinkingController);
                    final message = _messages[index];
                    return _ChatBubble(message: message);
                  },
                ),
              ),
              if (!_thinking)
                SizedBox(
                  height: 45,
                  child: ListView(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    scrollDirection: Axis.horizontal,
                    children: [
                      _SuggestionChip(label: 'My full financial picture', icon: Icons.auto_awesome, onTap: () => _addPrompt('Connect my overall financial picture')),
                      _SuggestionChip(label: 'Explore investments', icon: Icons.show_chart, onTap: () => _addPrompt('Explain my investment portfolio')),
                      _SuggestionChip(label: 'Review my wealth', icon: Icons.account_balance_wallet_outlined, onTap: () => _addPrompt('How has my wealth grown?')),
                      _SuggestionChip(label: 'Check credit health', icon: Icons.speed, onTap: () => _addPrompt('How can I improve my credit score?')),
                    ],
                  ),
                ),
              SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(14, 9, 14, 12),
                  child: Row(
                    children: [
                      Container(
                        width: 44, height: 44,
                        decoration: const BoxDecoration(color: _panel, shape: BoxShape.circle),
                        child: const Icon(Icons.add, color: _lavender),
                      ),
                      const SizedBox(width: 9),
                      Expanded(
                        child: TextField(
                          controller: _inputController,
                          textInputAction: TextInputAction.send,
                          onSubmitted: (_) => _sendFollowUp(),
                          decoration: InputDecoration(
                            hintText: 'Continue the conversation…',
                            filled: true,
                            fillColor: _panel,
                            contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none),
                            suffixIcon: IconButton(
                              onPressed: _sendFollowUp,
                              icon: const Icon(Icons.arrow_upward_rounded, color: _lavender),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _addPrompt(String prompt) {
    setState(() {
      _messages.add(_ChatMessage(prompt, true));
      _thinking = true;
    });
    _generateMockAnswer(prompt);
  }
}

class _ChatMessage {
  const _ChatMessage(this.text, this.isUser);
  final String text;
  final bool isUser;
}

class _ChatBubble extends StatelessWidget {
  const _ChatBubble({required this.message});
  final _ChatMessage message;

  @override
  Widget build(BuildContext context) {
    final user = message.isUser;
    return Align(
      alignment: user ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.84),
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: user ? const Color(0xFF493064) : const Color(0xFF241731),
          borderRadius: BorderRadius.circular(20),
          border: user ? null : Border.all(color: _lavender.withOpacity(0.13)),
        ),
        child: user
            ? Text(message.text, style: const TextStyle(color: Colors.white, fontSize: 14, height: 1.45))
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(children: [Icon(Icons.auto_awesome, color: _lavender, size: 17), SizedBox(width: 7), Text('INVESTMATE INSIGHT', style: TextStyle(color: _muted, fontSize: 9, letterSpacing: 1.2, fontWeight: FontWeight.w700))]),
                  const SizedBox(height: 12),
                  Text(message.text, style: const TextStyle(color: Colors.white, fontSize: 14, height: 1.55)),
                  const SizedBox(height: 14),
                  _MockFinancialVisual(answer: message.text),
                  const SizedBox(height: 12),
                  const Text('Illustrative mock information', style: TextStyle(color: _muted, fontSize: 10)),
                ],
              ),
      ),
    );
  }
}

class _ThinkingIndicator extends StatelessWidget {
  const _ThinkingIndicator({required this.controller});
  final AnimationController controller;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, child) => Padding(
        padding: const EdgeInsets.only(bottom: 18),
        child: Row(
          children: [
            Container(
              width: 34, height: 34,
              decoration: BoxDecoration(shape: BoxShape.circle, color: _lavender.withOpacity(0.12), boxShadow: [BoxShadow(color: _lavender.withOpacity(0.2 + controller.value * 0.25), blurRadius: 18)]),
              child: const Icon(Icons.auto_awesome, color: _lavender, size: 18),
            ),
            const SizedBox(width: 10),
            Text('InvestMate is analysing your finances…', style: TextStyle(color: _muted.withOpacity(0.65 + controller.value * 0.35), fontSize: 12)),
            const SizedBox(width: 8),
            const SizedBox(width: 13, height: 13, child: CircularProgressIndicator(strokeWidth: 1.5, color: _lavender)),
          ],
        ),
      ),
    );
  }
}


class _MockFinancialVisual extends StatelessWidget {
  const _MockFinancialVisual({required this.answer});
  final String answer;

  @override
  Widget build(BuildContext context) {
    final q = answer.toLowerCase();
    if (q.contains('credit') || q.contains('score')) {
      return const _MetricVisual(
        title: 'Credit health',
        label: 'DEMO CREDIT SCORE',
        value: '782',
        detail: 'Very good',
        percentage: 0.78,
        amountLabel: '78% score indicator',
        color: Color(0xFF70DDAA),
        secondaryLabel: 'Credit utilization',
        secondaryValue: '24%',
      );
    }
    if (q.contains('investment') || q.contains('portfolio') || q.contains('stock')) {
      return const _MetricVisual(
        title: 'Investment overview',
        label: 'PORTFOLIO VALUE',
        value: '₹3,72,800',
        detail: '+8.6% illustrative returns',
        percentage: 0.68,
        amountLabel: '68% allocation view',
        color: Color(0xFF65C9D3),
        secondaryLabel: 'Invested amount',
        secondaryValue: '₹3,43,300',
      );
    }
    return const _MetricVisual(
      title: 'Wealth overview',
      label: 'DEMO NET WORTH',
      value: '₹8,45,250',
      detail: '+4.8% this month',
      percentage: 0.75,
      amountLabel: '75% progress illustration',
      color: Color(0xFFC18BFF),
      secondaryLabel: 'Assets',
      secondaryValue: '₹10,25,000',
    );
  }
}

class _MetricVisual extends StatelessWidget {
  const _MetricVisual({
    required this.title,
    required this.label,
    required this.value,
    required this.detail,
    required this.percentage,
    required this.amountLabel,
    required this.color,
    required this.secondaryLabel,
    required this.secondaryValue,
  });

  final String title;
  final String label;
  final String value;
  final String detail;
  final double percentage;
  final String amountLabel;
  final Color color;
  final String secondaryLabel;
  final String secondaryValue;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: const Color(0xFF30203F),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: color.withOpacity(0.22)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title.toUpperCase(),
              style: const TextStyle(
                color: _muted,
                fontSize: 9,
                letterSpacing: 1.2,
                fontWeight: FontWeight.w700,
              )),
          const SizedBox(height: 12),
          Row(
            children: [
              SizedBox(
                width: 76,
                height: 76,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox.expand(
                      child: CircularProgressIndicator(
                        value: percentage,
                        strokeWidth: 7,
                        backgroundColor: Colors.white.withOpacity(0.08),
                        valueColor: AlwaysStoppedAnimation<Color>(color),
                      ),
                    ),
                    Text('${(percentage * 100).round()}%',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                        )),
                  ],
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label,
                        style: const TextStyle(color: _muted, fontSize: 9)),
                    const SizedBox(height: 4),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Text(value,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 22,
                            fontWeight: FontWeight.w700,
                          )),
                    ),
                    const SizedBox(height: 5),
                    Text(detail,
                        style: TextStyle(
                          color: color,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        )),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Divider(color: Colors.white.withOpacity(0.08), height: 1),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(secondaryLabel,
                    style: const TextStyle(color: _muted, fontSize: 10)),
              ),
              Text(secondaryValue,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  )),
            ],
          ),
          const SizedBox(height: 5),
          Text(amountLabel,
              style: const TextStyle(color: _muted, fontSize: 9)),
        ],
      ),
    );
  }
}
