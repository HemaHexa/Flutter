INVESTMATE — HYBRID MODULAR BUILD

This ZIP contains the complete updated lib/ source for your current InvestMate
Flutter demo, reorganised into separate Dart files instead of putting every
screen and widget in one large home_screen.dart.

FILE STRUCTURE
lib/
  main.dart
  screens/
    home_screen.dart                 Main library entry + Home screen/navigation
    shared_widgets.dart              Shared UI, orb painter, dock, indicators
    wealth_screen.dart               Wealth dashboard and charts
    investment_screen.dart           Investment dashboard, holdings and trade UI
    credit_health_screen.dart        Credit health dashboard and score gauge
    ai_conversation_screen.dart      AI conversation and demo response visuals

DESIGN DIRECTION: HYBRID
- Keeps the signature animated purple AI home/orb.
- Adds a subtle teal ambient accent for a more balanced premium feel.
- Keeps the financial dashboards clear and data-focused.
- Retains existing circular swipe navigation and section indicators.
- Retains the unified mock AI advisor and contextual demo prompts.

INSTALL
1. Back up your existing project folder.
2. Extract this ZIP.
3. Replace your project's entire lib folder with the lib folder from this ZIP.
4. Keep your existing pubspec.yaml, android, ios and other platform folders.
5. Run in VS Code terminal:
   flutter pub get
   flutter run -d emulator-5554

IMPORTANT
This app uses fictional demo financial data and mock AI responses. It is not
connected to a real bank, brokerage, credit bureau or live AI service.

The ZIP archive is integrity-checked. It has not been compiled or emulator-
tested in this environment. If Flutter reports an error, send the full terminal
output or screenshot and we can fix it.
