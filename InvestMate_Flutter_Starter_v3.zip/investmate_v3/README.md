# InvestMate Flutter Starter — Version 3

## What's new
- Home chips now open the corresponding carousel section directly:
  - My wealth -> Wealth
  - Investments -> Investments
  - Credit health -> Credit Health
- Assistant responses now include a compact visual financial card:
  - Wealth: net worth and asset snapshot
  - Investments: portfolio value and return
  - Credit: demo score and utilization
- Keeps the existing conversational UI and mock response flow.

## Install
1. Extract this ZIP.
2. Copy the included `lib` folder into your existing Flutter project, replacing the existing `lib` folder.
3. Run from the project root:
   ```bash
   flutter pub get
   flutter run -d emulator-5554
   ```

## Important
All amounts, returns, and credit scores are illustrative mock data. There is no real AI, credit bureau, investment provider, bank connection, or transaction execution. Voice interaction is still a visual preview; speech-to-text is not connected.
